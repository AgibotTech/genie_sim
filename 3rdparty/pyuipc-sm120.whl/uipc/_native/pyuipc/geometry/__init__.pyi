from __future__ import annotations
import collections.abc
import numpy
import numpy.typing
import typing
import uipc._native.pyuipc
import uipc._native.pyuipc.core
from . import affine_body
__all__: list[str] = ['AttributeCollection', 'AttributeIO', 'AttributeSlotFloat', 'AttributeSlotI32', 'AttributeSlotI64', 'AttributeSlotMatrix12x12', 'AttributeSlotMatrix2x2', 'AttributeSlotMatrix3x3', 'AttributeSlotMatrix4x4', 'AttributeSlotMatrix6x6', 'AttributeSlotMatrix9x9', 'AttributeSlotString', 'AttributeSlotU32', 'AttributeSlotU64', 'AttributeSlotVector12', 'AttributeSlotVector2', 'AttributeSlotVector2i', 'AttributeSlotVector3', 'AttributeSlotVector3i', 'AttributeSlotVector4', 'AttributeSlotVector4i', 'AttributeSlotVector6', 'AttributeSlotVector9', 'CStringSpan', 'Geometry', 'GeometryAtlas', 'GeometrySlot', 'IAttributeSlot', 'IGeometry', 'ImplicitGeometry', 'ImplicitGeometrySlot', 'SimplicialComplex', 'SimplicialComplexIO', 'SimplicialComplexSlot', 'SpreadSheetIO', 'StringSpan', 'UrdfController', 'UrdfIO', 'affine_body', 'apply_region', 'apply_transform', 'closest_vertex_edge_pairs', 'closest_vertex_triangle_pairs', 'compute_mesh_d_hat', 'constitution_type', 'extract_surface', 'facet_closure', 'flip_inward_triangles', 'ground', 'halfplane', 'is_trimesh_closed', 'label_connected_vertices', 'label_open_edge', 'label_region', 'label_surface', 'label_triangle_orient', 'linemesh', 'merge', 'mesh_partition', 'optimal_transform', 'pointcloud', 'points_from_volume', 'tetmesh', 'trimesh']
class AttributeCollection:
    """
    AttributeCollection class for managing collections of attributes (scalars, vectors, matrices, strings).
    """
    def attribute_count(self) -> int:
        """
        Get the number of attributes.
        Returns:
            int: Number of attributes.
        """
    def clear(self) -> None:
        """
        Clear all attributes.
        """
    @typing.overload
    def create(self, name: str, value: int) -> IAttributeSlot:
        """
        Create an I32 (32-bit integer) attribute.
        Args:
            name: Attribute name.
            value: I32 scalar value.
        Returns:
            AttributeSlot: Created attribute slot.
        """
    @typing.overload
    def create(self, name: str, value: int) -> IAttributeSlot:
        """
        Create an I64 (64-bit integer) attribute.
        Args:
            name: Attribute name.
            value: I64 scalar value.
        Returns:
            AttributeSlot: Created attribute slot.
        """
    @typing.overload
    def create(self, name: str, value: int) -> IAttributeSlot:
        """
        Create a U64 (64-bit unsigned integer) attribute.
        Args:
            name: Attribute name.
            value: U64 scalar value.
        Returns:
            AttributeSlot: Created attribute slot.
        """
    @typing.overload
    def create(self, name: str, value: float) -> IAttributeSlot:
        """
        Create a Float (floating-point) attribute.
        Args:
            name: Attribute name.
            value: Float scalar value.
        Returns:
            AttributeSlot: Created attribute slot.
        """
    @typing.overload
    def create(self, name: str, value: numpy.typing.NDArray[numpy.float64]) -> IAttributeSlot:
        """
        Create an attribute from a numpy array (auto-detects type: scalar, vector, or matrix).
        Args:
            name: Attribute name.
            value: Numpy array (can be scalar, vector of size 2/3/4/6/9/12, or matrix of size 2x2/3x3/4x4/6x6/9x9/12x12).
        Returns:
            AttributeSlot: Created attribute slot.
        """
    @typing.overload
    def create(self, name: str, value: numpy.typing.NDArray[numpy.int32]) -> IAttributeSlot:
        """
        Create an integer attribute from a numpy array (auto-detects type: scalar or integer vector).
        Args:
            name: Attribute name.
            value: Numpy array (can be scalar or integer vector of size 2/3/4).
        Returns:
            AttributeSlot: Created attribute slot.
        """
    @typing.overload
    def create(self, name: str, value: str) -> AttributeSlotString:
        """
        Create a string attribute.
        Args:
            name: Attribute name.
            value: String value.
        Returns:
            AttributeSlot: Created attribute slot.
        """
    def destroy(self, name: str) -> None:
        """
        Destroy an attribute by name.
        Args:
            name: Attribute name to destroy.
        """
    def find(self, name: str) -> IAttributeSlot:
        """
        Find an attribute by name.
        Args:
            name: Attribute name.
        Returns:
            AttributeSlot or None: Attribute slot if found, None otherwise.
        """
    def reorder(self, indices: typing.Annotated[numpy.typing.ArrayLike, numpy.uint64]) -> None:
        """
        Reorder attributes according to the given indices.
        Args:
            indices: Array of new indices for reordering.
        """
    def reserve(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
        """
        Reserve capacity for attributes.
        Args:
            size: Capacity to reserve.
        """
    def resize(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
        """
        Resize all attributes to the specified size.
        Args:
            size: New size for all attributes.
        """
    def share(self, name: str, slot: IAttributeSlot) -> None:
        """
        Share an existing attribute slot with a new name.
        Args:
            name: New name for the shared attribute.
            slot: Attribute slot to share.
        """
    def size(self) -> int:
        """
        Get the size of attributes.
        Returns:
            int: Size of attributes.
        """
class AttributeIO:
    """
    AttributeIO class for reading attributes from files.
    """
    def __init__(self, file: str) -> None:
        """
        Create an AttributeIO instance.
        Args:
            file: File path to read from.
        """
    def read(self, name: str, slot: IAttributeSlot) -> None:
        """
        Read an attribute from the file.
        Args:
            name: Attribute name to read.
            slot: AttributeSlot to store the read data.
        """
class AttributeSlotFloat(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotI32(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.int32]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotI64(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.int64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotMatrix12x12(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotMatrix2x2(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotMatrix3x3(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotMatrix4x4(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotMatrix6x6(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotMatrix9x9(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotString(IAttributeSlot):
    def view(self) -> CStringSpan:
        """
        Get a view of the string attribute data.
        Returns:
            StringSpan: View of string attribute data.
        """
class AttributeSlotU32(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.uint32]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotU64(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.uint64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotVector12(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotVector2(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotVector2i(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.int32]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotVector3(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotVector3i(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.int32]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotVector4(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotVector4i(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.int32]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotVector6(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class AttributeSlotVector9(IAttributeSlot):
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a numpy array view of the attribute data.
        Returns:
            numpy.ndarray: Array view of attribute data.
        """
class CStringSpan:
    def __getitem__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> str:
        ...
    def __init__(self) -> None:
        ...
    def __iter__(self) -> collections.abc.Iterator[str]:
        ...
    def __len__(self) -> int:
        ...
    def __repr__(self) -> str:
        ...
class Geometry(IGeometry):
    """
    Geometry class representing geometric data with meta and instance attributes.
    """
    class InstanceAttributes:
        """
        Instance attributes for geometry instances (per-instance data).
        """
        def clear(self) -> None:
            """
            Clear all instance attributes.
            """
        def create(self, name: str, object: typing.Any) -> IAttributeSlot:
            """
            Create a new instance attribute from a Python object.
            Args:
                name: Attribute name.
                object: Python object to create attribute from.
            Returns:
                AttributeSlot: Created attribute slot.
            """
        def destroy(self, name: str) -> None:
            """
            Destroy an instance attribute by name.
            Args:
                name: Attribute name to destroy.
            """
        def find(self, name: str) -> IAttributeSlot:
            """
            Find an instance attribute by name.
            Args:
                name: Attribute name.
            Returns:
                AttributeSlot or None: Attribute slot if found, None otherwise.
            """
        def reserve(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
            """
            Reserve capacity for instance attributes.
            Args:
                size: Capacity to reserve.
            """
        def resize(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
            """
            Resize the instance attributes to the specified size.
            Args:
                size: New size for instance attributes.
            """
        def share(self, name: str, attribute: IAttributeSlot) -> None:
            """
            Share an existing attribute slot with a new name.
            Args:
                name: New name for the shared attribute.
                attribute: Attribute slot to share.
            """
        def size(self) -> int:
            """
            Get the number of instances.
            Returns:
                int: Number of instances.
            """
        def to_json(self) -> json:
            """
            Convert instance attributes to JSON.
            Returns:
                dict: JSON representation of instance attributes.
            """
    class MetaAttributes:
        """
        Meta attributes associated with the geometry (shared across instances).
        """
        def __repr__(self) -> str:
            """
            String representation of meta attributes.
            Returns:
                str: Formatted JSON string.
            """
        def create(self, name: str, object: typing.Any) -> IAttributeSlot:
            """
            Create a new meta attribute from a Python object.
            Args:
                name: Attribute name.
                object: Python object to create attribute from.
            Returns:
                AttributeSlot: Created attribute slot.
            """
        def destroy(self, name: str) -> None:
            """
            Destroy a meta attribute by name.
            Args:
                name: Attribute name to destroy.
            """
        def find(self, name: str) -> IAttributeSlot:
            """
            Find a meta attribute by name.
            Args:
                name: Attribute name.
            Returns:
                AttributeSlot or None: Attribute slot if found, None otherwise.
            """
        def share(self, name: str, attribute: IAttributeSlot) -> None:
            """
            Share an existing attribute slot with a new name.
            Args:
                name: New name for the shared attribute.
                attribute: Attribute slot to share.
            """
        def to_json(self) -> json:
            """
            Convert meta attributes to JSON.
            Returns:
                dict: JSON representation of meta attributes.
            """
    def __getitem__(self, name: str) -> AttributeCollection:
        """
        Get an attribute collection by name.
        Returns:
            AttributeCollection: Attribute collection with the given name, if not found, create a new one.
        """
    def __init__(self) -> None:
        """
        Create an empty geometry.
        """
    def __repr__(self) -> str:
        """
        String representation of the geometry.
        Returns:
            str: String representation.
        """
    def instances(self) -> Geometry.InstanceAttributes:
        """
        Get the instance attributes.
        Returns:
            InstanceAttributes: Instance attributes of the geometry.
        """
    def meta(self) -> Geometry.MetaAttributes:
        """
        Get the meta attributes.
        Returns:
            MetaAttributes: Meta attributes of the geometry.
        """
class GeometryAtlas:
    """
    GeometryAtlas class for managing multiple geometries and attribute collections.
    """
    def __init__(self) -> None:
        """
        Create an empty geometry atlas.
        """
    def attribute_collection_count(self) -> int:
        """
        Get the number of attribute collections.
        Returns:
            int: Number of attribute collections.
        """
    def attribute_collection_names(self) -> list:
        """
        Get the names of all attribute collections.
        Returns:
            list: List of attribute collection names.
        """
    @typing.overload
    def create(self, geo: Geometry) -> int:
        """
        Create a geometry in the atlas.
        Args:
            geo: Geometry to add.
        Returns:
            GeometrySlot: Slot containing the created geometry.
        """
    @typing.overload
    def create(self, name: str, ac: AttributeCollection) -> None:
        """
        Create a geometry from an attribute collection.
        Args:
            name: Name for the geometry.
            ac: AttributeCollection to create geometry from.
        Returns:
            GeometrySlot: Slot containing the created geometry.
        """
    def from_json(self, json: json) -> None:
        """
        Load atlas from JSON representation.
        Args:
            json: JSON dictionary to load from.
        """
    def geometry_count(self) -> int:
        """
        Get the number of geometries in the atlas.
        Returns:
            int: Number of geometries.
        """
    def to_json(self) -> json:
        """
        Convert atlas to JSON representation.
        Returns:
            dict: JSON representation of the atlas.
        """
class GeometrySlot:
    """
    GeometrySlot class representing a slot containing a geometry.
    """
    def geometry(self) -> Geometry:
        """
        Get the geometry in this slot.
        Returns:
            Geometry: Reference to the geometry.
        """
    def id(self) -> int:
        """
        Get the geometry slot ID.
        Returns:
            int: Geometry slot ID.
        """
class IAttributeSlot:
    """
    IAttributeSlot interface for attribute slots.
    """
    def allow_destroy(self) -> bool:
        """
        Check if the attribute can be destroyed.
        Returns:
            bool: True if destroyable, False otherwise.
        """
    def is_shared(self) -> bool:
        """
        Check if the attribute is shared.
        Returns:
            bool: True if shared, False otherwise.
        """
    def name(self) -> str:
        """
        Get the attribute name.
        Returns:
            str: Attribute name.
        """
    def size(self) -> int:
        """
        Get the size of the attribute.
        Returns:
            int: Number of elements.
        """
    def type_name(self) -> str:
        """
        Get the attribute type name.
        Returns:
            str: Type name.
        """
    def view(self) -> numpy.ndarray:
        """
        Get a view of the attribute data (virtual method, returns None for base class).
        Returns:
            numpy.ndarray or None: Array view if available, None otherwise.
        """
class IGeometry:
    """
    Interface for geometry types.
    """
    def clone(self) -> IGeometry:
        """
        Create a deep copy of the geometry.
        Returns:
            IGeometry: Cloned geometry.
        """
    def to_json(self) -> json:
        """
        Convert geometry to JSON representation.
        Returns:
            dict: JSON representation of the geometry.
        """
    def type(self) -> str:
        """
        Get the geometry type name.
        Returns:
            str: Geometry type name.
        """
class ImplicitGeometry(Geometry):
    """
    ImplicitGeometry class representing implicit surfaces (defined by functions, e.g., planes, spheres).
    """
    def __init__(self) -> None:
        """
        Create an empty implicit geometry.
        """
    def __repr__(self) -> str:
        """
        String representation of the implicit geometry.
        Returns:
            str: String representation.
        """
class ImplicitGeometrySlot(GeometrySlot):
    """
    ImplicitGeometrySlot class representing a slot containing an implicit geometry.
    """
    def geometry(self) -> ImplicitGeometry:
        """
        Get the implicit geometry in this slot.
        Returns:
            ImplicitGeometry: Reference to the implicit geometry.
        """
class SimplicialComplex(Geometry):
    """
    SimplicialComplex class representing a simplicial complex (mesh) with vertices, edges, triangles, and tetrahedra.
    """
    class EdgeAttributes:
        """
        Edge attributes for the simplicial complex.
        """
        def clear(self) -> None:
            """
            Clear all attributes.
            """
        def create(self, name: str, object: typing.Any) -> IAttributeSlot:
            """
            Create a new attribute from a Python object.
            Args:
                name: Attribute name.
                object: Python object to create attribute from.
            Returns:
                AttributeSlot: Created attribute slot.
            """
        def destroy(self, name: str) -> None:
            """
            Destroy an attribute by name.
            Args:
                name: Attribute name to destroy.
            """
        def find(self, name: str) -> IAttributeSlot:
            """
            Find an attribute by name.
            Args:
                name: Attribute name.
            Returns:
                AttributeSlot or None: Attribute slot if found, None otherwise.
            """
        def reserve(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
            """
            Reserve capacity for attributes.
            Args:
                size: Capacity to reserve.
            """
        def resize(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
            """
            Resize the attributes to the specified size.
            Args:
                size: New size.
            """
        def share(self, name: str, attribute: IAttributeSlot) -> None:
            """
            Share an existing attribute slot with a new name.
            Args:
                name: New name for the shared attribute.
                attribute: Attribute slot to share.
            """
        def size(self) -> int:
            """
            Get the number of simplices.
            Returns:
                int: Number of simplices.
            """
        def to_json(self) -> json:
            """
            Convert attributes to JSON representation.
            Returns:
                dict: JSON representation of the attributes.
            """
        def topo(self) -> AttributeSlotVector2i:
            """
            Get the topology attribute slot.
            Returns:
                AttributeSlot: Reference to topology attribute slot.
            """
    class TetrahedronAttributes:
        """
        Tetrahedron attributes for the simplicial complex.
        """
        def clear(self) -> None:
            """
            Clear all attributes.
            """
        def create(self, name: str, object: typing.Any) -> IAttributeSlot:
            """
            Create a new attribute from a Python object.
            Args:
                name: Attribute name.
                object: Python object to create attribute from.
            Returns:
                AttributeSlot: Created attribute slot.
            """
        def destroy(self, name: str) -> None:
            """
            Destroy an attribute by name.
            Args:
                name: Attribute name to destroy.
            """
        def find(self, name: str) -> IAttributeSlot:
            """
            Find an attribute by name.
            Args:
                name: Attribute name.
            Returns:
                AttributeSlot or None: Attribute slot if found, None otherwise.
            """
        def reserve(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
            """
            Reserve capacity for attributes.
            Args:
                size: Capacity to reserve.
            """
        def resize(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
            """
            Resize the attributes to the specified size.
            Args:
                size: New size.
            """
        def share(self, name: str, attribute: IAttributeSlot) -> None:
            """
            Share an existing attribute slot with a new name.
            Args:
                name: New name for the shared attribute.
                attribute: Attribute slot to share.
            """
        def size(self) -> int:
            """
            Get the number of simplices.
            Returns:
                int: Number of simplices.
            """
        def to_json(self) -> json:
            """
            Convert attributes to JSON representation.
            Returns:
                dict: JSON representation of the attributes.
            """
        def topo(self) -> AttributeSlotVector4i:
            """
            Get the topology attribute slot.
            Returns:
                AttributeSlot: Reference to topology attribute slot.
            """
    class TriangleAttributes:
        """
        Triangle attributes for the simplicial complex.
        """
        def clear(self) -> None:
            """
            Clear all attributes.
            """
        def create(self, name: str, object: typing.Any) -> IAttributeSlot:
            """
            Create a new attribute from a Python object.
            Args:
                name: Attribute name.
                object: Python object to create attribute from.
            Returns:
                AttributeSlot: Created attribute slot.
            """
        def destroy(self, name: str) -> None:
            """
            Destroy an attribute by name.
            Args:
                name: Attribute name to destroy.
            """
        def find(self, name: str) -> IAttributeSlot:
            """
            Find an attribute by name.
            Args:
                name: Attribute name.
            Returns:
                AttributeSlot or None: Attribute slot if found, None otherwise.
            """
        def reserve(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
            """
            Reserve capacity for attributes.
            Args:
                size: Capacity to reserve.
            """
        def resize(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
            """
            Resize the attributes to the specified size.
            Args:
                size: New size.
            """
        def share(self, name: str, attribute: IAttributeSlot) -> None:
            """
            Share an existing attribute slot with a new name.
            Args:
                name: New name for the shared attribute.
                attribute: Attribute slot to share.
            """
        def size(self) -> int:
            """
            Get the number of simplices.
            Returns:
                int: Number of simplices.
            """
        def to_json(self) -> json:
            """
            Convert attributes to JSON representation.
            Returns:
                dict: JSON representation of the attributes.
            """
        def topo(self) -> AttributeSlotVector3i:
            """
            Get the topology attribute slot.
            Returns:
                AttributeSlot: Reference to topology attribute slot.
            """
    class VertexAttributes:
        """
        Vertex attributes for the simplicial complex.
        """
        def clear(self) -> None:
            """
            Clear all attributes.
            """
        def create(self, name: str, object: typing.Any) -> IAttributeSlot:
            """
            Create a new attribute from a Python object.
            Args:
                name: Attribute name.
                object: Python object to create attribute from.
            Returns:
                AttributeSlot: Created attribute slot.
            """
        def destroy(self, name: str) -> None:
            """
            Destroy an attribute by name.
            Args:
                name: Attribute name to destroy.
            """
        def find(self, name: str) -> IAttributeSlot:
            """
            Find an attribute by name.
            Args:
                name: Attribute name.
            Returns:
                AttributeSlot or None: Attribute slot if found, None otherwise.
            """
        def reserve(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
            """
            Reserve capacity for attributes.
            Args:
                size: Capacity to reserve.
            """
        def resize(self, size: typing.SupportsInt | typing.SupportsIndex) -> None:
            """
            Resize the attributes to the specified size.
            Args:
                size: New size.
            """
        def share(self, name: str, attribute: IAttributeSlot) -> None:
            """
            Share an existing attribute slot with a new name.
            Args:
                name: New name for the shared attribute.
                attribute: Attribute slot to share.
            """
        def size(self) -> int:
            """
            Get the number of simplices.
            Returns:
                int: Number of simplices.
            """
        def to_json(self) -> json:
            """
            Convert attributes to JSON representation.
            Returns:
                dict: JSON representation of the attributes.
            """
    def __repr__(self) -> str:
        """
        String representation of the simplicial complex.
        Returns:
            str: String representation.
        """
    def copy(self) -> SimplicialComplex:
        """
        Create a copy of the simplicial complex.
        Returns:
            SimplicialComplex: Copy of the simplicial complex.
        """
    def dim(self) -> int:
        """
        Get the dimension of the simplicial complex.
        Returns:
            int: Dimension (0=points, 1=edges, 2=triangles, 3=tetrahedra).
        """
    def edges(self) -> SimplicialComplex.EdgeAttributes:
        """
        Get the edge attributes.
        Returns:
            EdgeAttributes: Edge attributes collection.
        """
    def positions(self) -> AttributeSlotVector3:
        """
        Get the position attribute slot (3D vertex positions).
        Returns:
            AttributeSlot: Reference to position attribute slot.
        """
    def tetrahedra(self) -> SimplicialComplex.TetrahedronAttributes:
        """
        Get the tetrahedron attributes.
        Returns:
            TetrahedronAttributes: Tetrahedron attributes collection.
        """
    def transforms(self) -> AttributeSlotMatrix4x4:
        """
        Get the transform attribute slot (4x4 transformation matrices).
        Returns:
            AttributeSlot: Reference to transform attribute slot.
        """
    def triangles(self) -> SimplicialComplex.TriangleAttributes:
        """
        Get the triangle attributes.
        Returns:
            TriangleAttributes: Triangle attributes collection.
        """
    def vertices(self) -> SimplicialComplex.VertexAttributes:
        """
        Get the vertex attributes.
        Returns:
            VertexAttributes: Vertex attributes collection.
        """
class SimplicialComplexIO:
    """
    SimplicialComplexIO class for reading and writing simplicial complexes to/from files.
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Create a SimplicialComplexIO instance without pre-transform.
        """
    @typing.overload
    def __init__(self, pre_transform: uipc._native.pyuipc.Transform) -> None:
        """
        Create a SimplicialComplexIO instance with a pre-transform.
        Args:
            pre_transform: Transform to apply before reading/writing.
        """
    @typing.overload
    def __init__(self, pre_transform: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Create a SimplicialComplexIO instance with a pre-transform matrix.
        Args:
            pre_transform: 4x4 transformation matrix.
        """
    def read(self, filename: str) -> SimplicialComplex:
        """
        Read a simplicial complex from a file.
        Args:
            filename: Input file path.
        Returns:
            SimplicialComplex: Loaded simplicial complex.
        """
    def write(self, sc: str, filename: SimplicialComplex) -> None:
        """
        Write a simplicial complex to a file.
        Args:
            sc: SimplicialComplex to write.
            filename: Output file path.
        """
class SimplicialComplexSlot(GeometrySlot):
    """
    SimplicialComplexSlot class representing a slot containing a simplicial complex.
    """
    def geometry(self) -> SimplicialComplex:
        """
        Get the simplicial complex in this slot.
        Returns:
            SimplicialComplex: Reference to the simplicial complex.
        """
class SpreadSheetIO:
    """
    SpreadSheetIO class for writing simplicial complexes to spreadsheet formats (JSON, CSV).
    """
    def __init__(self, output_folder: str = './') -> None:
        """
        Create a SpreadSheetIO instance.
        Args:
            output_folder: Output folder path (default: './').
        """
    @typing.overload
    def write_csv(self, geo_name: str, simplicial_complex: SimplicialComplex) -> None:
        """
        Write a simplicial complex to CSV format with a geometry name.
        Args:
            geo_name: Name for the geometry.
            simplicial_complex: SimplicialComplex to write.
        """
    @typing.overload
    def write_csv(self, simplicial_complex: SimplicialComplex) -> None:
        """
        Write a simplicial complex to CSV format.
        Args:
            simplicial_complex: SimplicialComplex to write.
        """
    @typing.overload
    def write_json(self, geo_name: str, simplicial_complex: SimplicialComplex) -> None:
        """
        Write a simplicial complex to JSON format with a geometry name.
        Args:
            geo_name: Name for the geometry.
            simplicial_complex: SimplicialComplex to write.
        """
    @typing.overload
    def write_json(self, simplicial_complex: SimplicialComplex) -> None:
        """
        Write a simplicial complex to JSON format.
        Args:
            simplicial_complex: SimplicialComplex to write.
        """
class StringSpan:
    def __getitem__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> str:
        ...
    def __init__(self) -> None:
        ...
    def __iter__(self) -> collections.abc.Iterator[str]:
        ...
    def __len__(self) -> int:
        ...
    def __repr__(self) -> str:
        ...
    def __setitem__(self, arg0: typing.SupportsInt | typing.SupportsIndex, arg1: str) -> None:
        ...
class UrdfController:
    """
    UrdfController class for controlling URDF robot models.
    """
    def apply_to(self, attr: str) -> None:
        """
        Apply controller state to attributes.
        Args:
            attr: Attribute collection to apply to.
        """
    def links(self) -> list:
        """
        Get the list of link names.
        Returns:
            list: List of link names.
        """
    def move_root(self, xyz: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], rpy: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Move the root link of the robot.
        Args:
            xyz: Translation vector (3D).
            rpy: Rotation vector (roll, pitch, yaw in radians).
        """
    def revolute_joints(self) -> ImplicitGeometrySlot:
        """
        Get the list of revolute joint names.
        Returns:
            list: List of revolute joint names.
        """
    def rotate_to(self, joint_name: str, angle: typing.SupportsFloat | typing.SupportsIndex) -> None:
        """
        Set the rotation angle of a revolute joint.
        Args:
            joint_name: Name of the joint.
            angle: Rotation angle in radians.
        """
    def sync_visual_mesh(self) -> None:
        """
        Synchronize visual mesh with current joint positions.
        """
class UrdfIO:
    """
    UrdfIO class for loading URDF robot models.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default UrdfIO configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {'load_visual_mesh': True}) -> None:
        """
        Create a UrdfIO instance.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def read(self, object: uipc._native.pyuipc.core.Object, urdf_path: str) -> UrdfController:
        """
        Read a URDF file and populate an object.
        Args:
            object: Object to populate with URDF data.
            urdf_path: Path to the URDF file.
        Returns:
            Controller for the loaded URDF model.
        """
def apply_region(sc: SimplicialComplex) -> list:
    """
    Split a simplicial complex by regions.
    Args:
        sc: SimplicialComplex with region labels.
    Returns:
        list: List of SimplicialComplex objects, one per region.
    """
def apply_transform(sc: SimplicialComplex) -> list:
    """
    Apply transforms to a simplicial complex, splitting into multiple complexes.
    Args:
        sc: SimplicialComplex with transforms.
    Returns:
        list: List of transformed SimplicialComplex objects.
    """
def closest_vertex_edge_pairs(vertex_mesh: SimplicialComplex, edge_mesh: SimplicialComplex, max_distance: typing.SupportsFloat | typing.SupportsIndex) -> Geometry:
    """
    Find vertex-edge pairs between two meshes within max_distance.
    
    Args:
        vertex_mesh: SimplicialComplex providing vertices (point set).
        edge_mesh: SimplicialComplex providing edges.
        max_distance: Max point-edge distance; only pairs within this are returned.
    
    Returns:
        Geometry: One instance per pair; each instance has topo (Vector2i) = (vertex_index, edge_index).
        Compatible with SoftVertexEdgeStitch.create_geometry(..., pair_geometry, ...).
    """
def closest_vertex_triangle_pairs(vertex_mesh: SimplicialComplex, triangle_mesh: SimplicialComplex, max_distance: typing.SupportsFloat | typing.SupportsIndex, max_distance_attr: str = '', group: str = '') -> Geometry:
    """
    Find vertex–triangle pairs between two meshes within max_distance.
    
    Args:
        vertex_mesh: SimplicialComplex providing vertices (point set).
        triangle_mesh: SimplicialComplex providing triangles.
        max_distance: Max point–triangle distance; only pairs within this are returned.
        max_distance_attr: Optional vertex Float attribute name for per-vertex max distance.
        group: Optional IndexT attribute name on vertices/triangles; only value 1 is selected.
    
    Returns:
        Geometry: One instance per pair; each instance has topo (Vector2i) = (vertex_index, triangle_index).
        Compatible with SoftVertexTriangleStitch.create_geometry(..., pair_geometry, ...).
    """
def compute_mesh_d_hat(sc: SimplicialComplex, max_d_hat: typing.SupportsFloat | typing.SupportsIndex) -> AttributeSlotFloat:
    """
    Compute mesh d_hat (characteristic length) parameter.
    Args:
        sc: SimplicialComplex to compute for.
        max_d_hat: Maximum d_hat value.
    Returns:
        float: Computed d_hat value.
    """
def constitution_type(geo: Geometry) -> str:
    """
    Get the constitution type for a geometry.
    Args:
        geo: Geometry to check.
    Returns:
        str: Constitution type name.
    """
@typing.overload
def extract_surface(sc: SimplicialComplex) -> SimplicialComplex:
    """
    Extract surface from a simplicial complex.
    Args:
        sc: SimplicialComplex to extract surface from.
    Returns:
        SimplicialComplex: Surface mesh.
    """
@typing.overload
def extract_surface(sc: list) -> SimplicialComplex:
    """
    Extract surface from multiple simplicial complexes.
    Args:
        sc: List of SimplicialComplex objects.
    Returns:
        SimplicialComplex: Combined surface mesh.
    """
def facet_closure(sc: SimplicialComplex) -> SimplicialComplex:
    """
    Compute the facet closure of a simplicial complex.
    Args:
        sc: SimplicialComplex to compute closure for.
    Returns:
        SimplicialComplex: Facet closure.
    """
def flip_inward_triangles(sc: SimplicialComplex) -> SimplicialComplex:
    """
    Flip inward-facing triangles to face outward.
    Args:
        sc: SimplicialComplex to modify.
    """
def ground(height: typing.SupportsFloat | typing.SupportsIndex = 0.0, N: typing.Annotated[numpy.typing.ArrayLike, numpy.float64] = ...) -> ImplicitGeometry:
    """
    Create a ground plane implicit geometry.
    Args:
        height: Height of the ground plane (default: 0.0).
        N: Normal vector of the ground plane (default: Y-axis).
    Returns:
        ImplicitGeometry: Ground plane.
    """
def halfplane(P: typing.Annotated[numpy.typing.ArrayLike, numpy.float64] = ..., N: typing.Annotated[numpy.typing.ArrayLike, numpy.float64] = ...) -> ImplicitGeometry:
    """
    Create a half-plane implicit geometry.
    Args:
        P: Point on the plane (default: origin).
        N: Normal vector of the plane (default: Y-axis).
    Returns:
        ImplicitGeometry: Half-plane.
    """
def is_trimesh_closed(sc: SimplicialComplex) -> bool:
    """
    Check if a triangular mesh is closed (watertight).
    Args:
        sc: SimplicialComplex to check.
    Returns:
        bool: True if closed, False otherwise.
    """
def label_connected_vertices(sc: SimplicialComplex) -> AttributeSlotI32:
    """
    Label connected components of vertices.
    Args:
        sc: SimplicialComplex to label.
    """
def label_open_edge(sc: SimplicialComplex) -> AttributeSlotI32:
    """
    Label open edges in a trimesh.
    An edge is considered open if it is shared by exactly 1 triangle.
    An edge shared by 2 triangles is a normal closed edge.
    Args:
        sc: SimplicialComplex to label.
    Returns:
        AttributeSlot: The `is_open` attribute slot on edges (1 = open, 0 = closed).
    """
def label_region(sc: SimplicialComplex) -> None:
    """
    Label regions in a simplicial complex.
    Args:
        sc: SimplicialComplex to label.
    """
def label_surface(sc: SimplicialComplex) -> None:
    """
    Label surface elements in a simplicial complex.
    Args:
        sc: SimplicialComplex to label.
    """
def label_triangle_orient(sc: SimplicialComplex) -> AttributeSlotI32:
    """
    Label triangle orientations in a simplicial complex.
    Args:
        sc: SimplicialComplex to label.
    """
def linemesh(Vs: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], Es: typing.Annotated[numpy.typing.ArrayLike, numpy.int32]) -> SimplicialComplex:
    """
    Create a line mesh from vertices and edges.
    Args:
        Vs: Array of vertex positions (Nx3).
        Es: Array of edge indices (Mx2).
    Returns:
        SimplicialComplex: Line mesh.
    """
def merge(sc_list: list) -> SimplicialComplex:
    """
    Merge multiple simplicial complexes into one.
    Args:
        sc_list: List of SimplicialComplex objects to merge.
    Returns:
        SimplicialComplex: Merged simplicial complex.
    """
def mesh_partition(sc: SimplicialComplex, part_max_size: typing.SupportsInt | typing.SupportsIndex = 16) -> None:
    """
    Partition the simplicial complex using METIS graph partitioning.
    
    Creates a 'mesh_part' vertex attribute on the simplicial complex.
    This must be called before world.init() to enable the MAS preconditioner.
    
    Args:
        sc: SimplicialComplex to partition.
        part_max_size: Maximum number of vertices per partition (default: 16).
    """
@typing.overload
def optimal_transform(src: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], dst: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
    """
    Compute optimal transform between two point sets.
    Args:
        src: Source points (Nx3 array).
        dst: Destination points (Nx3 array).
    Returns:
        numpy.ndarray: 4x4 transformation matrix.
    """
@typing.overload
def optimal_transform(src: SimplicialComplex, dst: SimplicialComplex) -> numpy.typing.NDArray[numpy.float64]:
    """
    Compute optimal transform between two simplicial complexes.
    Args:
        src: Source SimplicialComplex.
        dst: Destination SimplicialComplex.
    Returns:
        numpy.ndarray: 4x4 transformation matrix.
    """
def pointcloud(Vs: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> SimplicialComplex:
    """
    Create a point cloud from vertices.
    Args:
        Vs: Array of vertex positions (Nx3).
    Returns:
        SimplicialComplex: Point cloud.
    """
def points_from_volume(sc: SimplicialComplex, resolution: typing.SupportsFloat | typing.SupportsIndex = 0.01) -> SimplicialComplex:
    """
    Generate points from a volume mesh.
    Args:
        sc: SimplicialComplex (volume mesh).
        resolution: Point sampling resolution (default: 0.01).
    Returns:
        SimplicialComplex: Point cloud.
    """
def tetmesh(Vs: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], Ts: typing.Annotated[numpy.typing.ArrayLike, numpy.int32]) -> SimplicialComplex:
    """
    Create a tetrahedral mesh from vertices and tetrahedra.
    Args:
        Vs: Array of vertex positions (Nx3).
        Ts: Array of tetrahedron indices (Mx4).
    Returns:
        SimplicialComplex: Tetrahedral mesh.
    """
def trimesh(Vs: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], Fs: typing.Annotated[numpy.typing.ArrayLike, numpy.int32]) -> SimplicialComplex:
    """
    Create a triangular mesh from vertices and faces.
    Args:
        Vs: Array of vertex positions (Nx3).
        Fs: Array of face indices (Mx3 for triangles or Mx4 for quads).
    Returns:
        SimplicialComplex: Triangular mesh.
    """
