from __future__ import annotations
import numpy
import numpy.typing
import typing
import uipc._native.pyuipc.geometry
__all__: list[str] = ['build_abd_mass_matrix', 'compute_body_force', 'compute_dyadic_mass', 'from_rigid_body', 'q_to_transform', 'q_v_to_transform_v', 'to_rigid_body', 'transform_to_q', 'transform_v_to_q_v']
def build_abd_mass_matrix(m: typing.SupportsFloat | typing.SupportsIndex, m_x_bar: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], m_x_bar_x_bar: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
    """
    Build the 12x12 ABD mass matrix from dyadic mass components.
    Args:
        m: Total mass.
        m_x_bar: First moment of mass (m * center_of_mass), 3D vector.
        m_x_bar_x_bar: Second moment of mass tensor S, 3x3 matrix.
    Returns:
        numpy.ndarray: 12x12 ABD mass matrix.
    """
def compute_body_force(sc: uipc._native.pyuipc.geometry.SimplicialComplex, body_force_density: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
    """
    Compute the body force of an affine body.
    Args:
        sc: The simplicial complex.
        body_force_density: The body force density in N/m^3 (3D vector).
    Returns:
        numpy.ndarray: 12D body force vector.
    """
def compute_dyadic_mass(sc: uipc._native.pyuipc.geometry.SimplicialComplex, rho: typing.SupportsFloat | typing.SupportsIndex) -> tuple:
    """
    Compute the dyadic mass of a simplicial complex.
    Integrate the mass density over the simplicial complex to compute the dyadic mass.
    Args:
        sc: The simplicial complex.
        rho: Mass density.
    Returns:
        tuple: (m, m_x_bar, m_x_bar_x_bar) where:
            - m: The total mass (float).
            - m_x_bar: The total mass times the center of mass (3D vector).
            - m_x_bar_x_bar: The total mass times the center of mass times the center of mass transpose (3x3 matrix).
    """
def from_rigid_body(mass: typing.SupportsFloat | typing.SupportsIndex, center_of_mass: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], inertia_cm: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
    """
    Build the 12x12 ABD mass matrix from rigid body quantities.
    Args:
        mass: Total mass of the rigid body.
        center_of_mass: Center of mass in the reference configuration (3D vector).
        inertia_cm: 3x3 inertia tensor about the center of mass.
    Returns:
        numpy.ndarray: 12x12 ABD mass matrix.
    """
def q_to_transform(q: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
    """
    Convert a 12D configuration vector to a 4x4 transformation matrix.
    Supports both single and batched operations.
    Args:
        q: 12D vector [translation(3), rotation_row0(3), rotation_row1(3), rotation_row2(3)] 
           or array of shape (N, 12) for batched processing.
    Returns:
        numpy.ndarray: 4x4 transformation matrix or array of shape (N, 4, 4) for batched input.
    """
def q_v_to_transform_v(q: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
    """
    Convert a 12D velocity vector to a 4x4 velocity transformation matrix.
    Supports both single and batched operations.
    Args:
        q: 12D velocity vector [translation(3), rotation_row0(3), rotation_row1(3), rotation_row2(3)]
           or array of shape (N, 12) for batched processing.
    Returns:
        numpy.ndarray: 4x4 velocity transformation matrix (last row is zero) 
                      or array of shape (N, 4, 4) for batched input.
    """
@typing.overload
def to_rigid_body(m: typing.SupportsFloat | typing.SupportsIndex, m_x_bar: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], m_x_bar_x_bar: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> tuple:
    """
    Extract rigid body properties from dyadic mass components.
    Args:
        m: Total mass.
        m_x_bar: First moment of mass (m * center_of_mass), 3D vector.
        m_x_bar_x_bar: Second moment of mass tensor S, 3x3 matrix.
    Returns:
        tuple: (total_mass, center_of_mass, inertia_cm) where:
            - total_mass: Total mass (float).
            - center_of_mass: Center of mass in the reference frame (3D vector).
            - inertia_cm: 3x3 inertia tensor about the center of mass.
    """
@typing.overload
def to_rigid_body(mass_matrix: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> tuple:
    """
    Extract rigid body properties from a 12x12 ABD mass matrix.
    Args:
        mass_matrix: 12x12 ABD mass matrix.
    Returns:
        tuple: (total_mass, center_of_mass, inertia_cm) where:
            - total_mass: Total mass (float).
            - center_of_mass: Center of mass in the reference frame (3D vector).
            - inertia_cm: 3x3 inertia tensor about the center of mass.
    """
def transform_to_q(transform: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
    """
    Convert a 4x4 transformation matrix to a 12D configuration vector.
    Supports both single and batched operations.
    Args:
        transform: 4x4 transformation matrix or array of shape (N, 4, 4) for batched processing.
    Returns:
        numpy.ndarray: 12D vector [translation(3), rotation_row0(3), rotation_row1(3), rotation_row2(3)]
                      or array of shape (N, 12, 1) for batched input.
    """
def transform_v_to_q_v(transform_v: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
    """
    Convert a 4x4 velocity transformation matrix to a 12D velocity vector.
    Supports both single and batched operations.
    Args:
        transform_v: 4x4 velocity transformation matrix or array of shape (N, 4, 4) for batched processing.
    Returns:
        numpy.ndarray: 12D velocity vector [translation(3), rotation_row0(3), rotation_row1(3), rotation_row2(3)]
                      or array of shape (N, 12, 1) for batched input.
    """
