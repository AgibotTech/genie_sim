from __future__ import annotations
__all__: list[str] = ['GPa', 'MPa', 'N', 'Pa', 'kPa', 'km', 'm', 'mm', 's']
GPa: float = 1000000000.0
MPa: float = 1000000.0
N: float = 1.0
Pa: float = 1.0
kPa: float = 1000.0
km: float = 1000.0
m: float = 1.0
mm: float = 0.001
s: float = 1.0
