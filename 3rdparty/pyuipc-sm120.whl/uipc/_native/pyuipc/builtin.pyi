from __future__ import annotations
import typing
__all__: list[str] = ['AbstractSimplicialComplex', 'AffineBody', 'ConstitutionUIDCollection', 'Constraint', 'FiniteElement', 'Geometry', 'ImplicitGeometry', 'ImplicitGeometryUIDCollection', 'InterAffineBody', 'InterPrimitive', 'SimplicialComplex', 'UIDInfo', 'UIDRegister', 'abd_mass', 'abd_mass_x_bar', 'abd_mass_x_bar_x_bar', 'adaptive', 'aim_position', 'aim_transform', 'backend_abd_body_offset', 'backend_fem_vertex_offset', 'constitution_uid', 'constraint_uids', 'contact_element_id', 'd_hat', 'dof_count', 'dof_offset', 'external_kinetic', 'extra_constitution_uids', 'global_vertex_offset', 'gravity', 'implicit_geometry_uid', 'is_codim', 'is_constrained', 'is_dynamic', 'is_facet', 'is_fixed', 'is_surf', 'mass_density', 'orient', 'parent_id', 'position', 'self_collision', 'subscene_element_id', 'thickness', 'topo', 'transform', 'velocity', 'volume']
class ConstitutionUIDCollection(UIDRegister):
    """
    Collection of constitution UIDs (unique identifiers for constitutions).
    """
    @staticmethod
    def instance() -> ConstitutionUIDCollection:
        """
        Get the singleton instance of the constitution UID collection.
        Returns:
            ConstitutionUIDCollection: Singleton instance.
        """
class ImplicitGeometryUIDCollection(UIDRegister):
    """
    Collection of implicit geometry UIDs (unique identifiers for implicit geometries).
    """
    @staticmethod
    def instance() -> ImplicitGeometryUIDCollection:
        """
        Get the singleton instance of the implicit geometry UID collection.
        Returns:
            ImplicitGeometryUIDCollection: Singleton instance.
        """
class UIDInfo:
    """
    UIDInfo class containing information about a UID (unique identifier).
    """
    def is_official_builtin_uid(self, uid: typing.SupportsInt | typing.SupportsIndex) -> bool:
        """
        Check if UID is an official builtin UID.
        """
    def is_user_defined_uid(self, uid: typing.SupportsInt | typing.SupportsIndex) -> bool:
        """
        Check if UID is a user-defined UID.
        """
    def to_json(self) -> json:
        """
        Convert to JSON representation.
        """
    @property
    def author(self) -> str:
        """
        Author of the UID.
        """
    @author.setter
    def author(self, arg0: str) -> None:
        ...
    @property
    def description(self) -> str:
        """
        Description of the UID.
        """
    @description.setter
    def description(self, arg0: str) -> None:
        ...
    @property
    def email(self) -> str:
        """
        Email of the author.
        """
    @email.setter
    def email(self, arg0: str) -> None:
        ...
    @property
    def extras(self) -> json:
        """
        Extra JSON data.
        """
    @extras.setter
    def extras(self, arg0: json) -> None:
        ...
    @property
    def name(self) -> str:
        """
        Name associated with the UID.
        """
    @name.setter
    def name(self, arg0: str) -> None:
        ...
    @property
    def type(self) -> str:
        """
        Type of the UID.
        """
    @type.setter
    def type(self, arg0: str) -> None:
        ...
    @property
    def uid(self) -> int:
        """
        UID value.
        """
    @uid.setter
    def uid(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    @property
    def website(self) -> str:
        """
        Website URL.
        """
    @website.setter
    def website(self, arg0: str) -> None:
        ...
class UIDRegister:
    """
    UIDRegister class for registering and looking up UIDs (unique identifiers).
    """
    def exists(self, uid: typing.SupportsInt | typing.SupportsIndex) -> bool:
        """
        Check if a UID exists in the register.
        Args:
            uid: UID to check.
        Returns:
            bool: True if UID exists, False otherwise.
        """
    def find(self, uid: typing.SupportsInt | typing.SupportsIndex) -> UIDInfo:
        """
        Find a UID in the register.
        Args:
            uid: UID to find.
        Returns:
            UIDInfo: UID information if found.
        """
    def to_json(self) -> json:
        """
        Convert register to JSON representation.
        Returns:
            dict: JSON representation of the register.
        """
AbstractSimplicialComplex: str = 'AbstractSimplicialComplex'
AffineBody: str = 'AffineBody'
Constraint: str = 'Constraint'
FiniteElement: str = 'FiniteElement'
Geometry: str = 'Geometry'
ImplicitGeometry: str = 'ImplicitGeometry'
InterAffineBody: str = 'InterAffineBody'
InterPrimitive: str = 'InterPrimitive'
SimplicialComplex: str = 'SimplicialComplex'
abd_mass: str = 'abd_mass'
abd_mass_x_bar: str = 'abd_mass_x_bar'
abd_mass_x_bar_x_bar: str = 'abd_mass_x_bar_x_bar'
adaptive: float = -1.0
aim_position: str = 'aim_position'
aim_transform: str = 'aim_transform'
backend_abd_body_offset: str = 'backend_abd_body_offset'
backend_fem_vertex_offset: str = 'backend_fem_vertex_offset'
constitution_uid: str = 'constitution_uid'
constraint_uids: str = 'constraint_uids'
contact_element_id: str = 'contact_element_id'
d_hat: str = 'd_hat'
dof_count: str = 'dof_count'
dof_offset: str = 'dof_offset'
external_kinetic: str = 'external_kinetic'
extra_constitution_uids: str = 'extra_constitution_uids'
global_vertex_offset: str = 'global_vertex_offset'
gravity: str = 'gravity'
implicit_geometry_uid: str = 'implicit_geometry_uid'
is_codim: str = 'is_codim'
is_constrained: str = 'is_constrained'
is_dynamic: str = 'is_dynamic'
is_facet: str = 'is_facet'
is_fixed: str = 'is_fixed'
is_surf: str = 'is_surf'
mass_density: str = 'mass_density'
orient: str = 'orient'
parent_id: str = 'parent_id'
position: str = 'position'
self_collision: str = 'self_collision'
subscene_element_id: str = 'subscene_element_id'
thickness: str = 'thickness'
topo: str = 'topo'
transform: str = 'transform'
velocity: str = 'velocity'
volume: str = 'volume'
