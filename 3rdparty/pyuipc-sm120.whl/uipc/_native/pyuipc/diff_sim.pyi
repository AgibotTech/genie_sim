from __future__ import annotations
import numpy
import numpy.typing
import typing
__all__: list[str] = ['ParameterCollection']
class ParameterCollection:
    """
    ParameterCollection class for managing simulation parameters.
    """
    def broadcast(self) -> None:
        """
        Broadcast parameter values across all instances.
        """
    def resize(self, N: typing.SupportsInt | typing.SupportsIndex, default_value: typing.SupportsFloat | typing.SupportsIndex = 0.0) -> None:
        """
        Resize the parameter collection.
        Args:
            N: New size.
            default_value: Default value for new parameters (default: 0.0).
        """
    def view(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get a view of the parameters as a numpy array.
        Returns:
            numpy.ndarray: Array view of parameters.
        """
