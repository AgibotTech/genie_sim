from __future__ import annotations
import collections.abc
import typing
import typing_extensions
import uipc._native.pyuipc.core
import uipc._native.pyuipc.diff_sim
import uipc._native.pyuipc.geometry
__all__: list[str] = ['AnimatorVisitor', 'Buffer', 'BufferView', 'DiffSimVisitor', 'SceneVisitor', 'WorldVisitor']
class AnimatorVisitor:
    """
    AnimatorVisitor class for accessing animator data from backend.
    """
    def __init__(self, animator: uipc._native.pyuipc.core.Animator) -> None:
        """
        Create an AnimatorVisitor for an animator.
        """
    def init(self) -> None:
        """
        Initialize the animator visitor.
        """
    def substep(self) -> int:
        """
        Get the current substep.
        """
    def update(self) -> None:
        """
        Update the animator visitor.
        """
class Buffer:
    def __init__(self: typing_extensions.Buffer, resize_func: collections.abc.Callable, get_buffer_view_func: collections.abc.Callable) -> None:
        """
        Constructs a Buffer object with provided resize and get_buffer_view functions.
        Args:
            resize_func f:(int)->None: Function to resize the buffer.
            get_buffer_view_func f:()->BufferView: Function to retrieve the buffer view.
        """
    def resize(self: typing_extensions.Buffer, size: typing.SupportsInt | typing.SupportsIndex) -> None:
        """
        Resize the buffer.
        Args:
            size: New size in elements.
        """
    def view(self: typing_extensions.Buffer) -> BufferView:
        """
        Get a view of the buffer.
        Returns:
            BufferView: View of the buffer.
        """
class BufferView:
    """
    BufferView class representing a view into a backend buffer.
    """
    def __bool__(self) -> bool:
        """
        Check if the buffer view is valid.
        Returns:
            bool: True if valid, False otherwise.
        """
    @typing.overload
    def __init__(self) -> None:
        """
        Create an empty buffer view.
        """
    @typing.overload
    def __init__(self, handle: typing.SupportsInt | typing.SupportsIndex, element_offset: typing.SupportsInt | typing.SupportsIndex, element_count: typing.SupportsInt | typing.SupportsIndex, element_size: typing.SupportsInt | typing.SupportsIndex, element_stride: typing.SupportsInt | typing.SupportsIndex, backend_name: str) -> None:
        """
        Create a buffer view with specified parameters.
        Args:
            handle: Backend handle to the buffer.
            element_offset: Offset in elements from the start of the buffer.
            element_count: Number of elements in the view.
            element_size: Size of each element in bytes.
            element_stride: Stride between elements in bytes.
            backend_name: Name of the backend.
        """
    def __repr__(self) -> str:
        """
        String representation of the buffer view.
        Returns:
            str: Formatted string representation.
        """
    def backend(self) -> str:
        """
        Get the backend name.
        Returns:
            str: Backend name.
        """
    def element_size(self) -> int:
        """
        Get the element size in bytes.
        Returns:
            int: Element size in bytes.
        """
    def element_stride(self) -> int:
        """
        Get the element stride in bytes.
        Returns:
            int: Element stride in bytes.
        """
    def handle(self) -> int:
        """
        Get the backend handle.
        Returns:
            int: Backend handle value.
        """
    def offset(self) -> int:
        """
        Get the element offset.
        Returns:
            int: Element offset.
        """
    def size(self) -> int:
        """
        Get the number of elements.
        Returns:
            int: Number of elements.
        """
    def size_in_bytes(self) -> int:
        """
        Get the total size in bytes.
        Returns:
            int: Total size in bytes.
        """
    def subview(self, offset: typing.SupportsInt | typing.SupportsIndex, element_count: typing.SupportsInt | typing.SupportsIndex) -> BufferView:
        """
        Create a subview of this buffer view.
        Args:
            offset: Element offset from the start of this view.
            element_count: Number of elements in the subview.
        Returns:
            BufferView: New buffer view representing the subview.
        """
class DiffSimVisitor:
    """
    DiffSimVisitor class for accessing differential simulator data from backend.
    """
    def parameters(self) -> uipc._native.pyuipc.diff_sim.ParameterCollection:
        """
        Get the parameter collection.
        Returns:
            ParameterCollection: Reference to parameter collection.
        """
class SceneVisitor:
    """
    SceneVisitor class for accessing scene data from backend.
    """
    class GeometrySlotSpan:
        """
        Span class for viewing contiguous sequences of data.
        """
        def __getitem__(self, index: typing.SupportsInt | typing.SupportsIndex) -> uipc._native.pyuipc.geometry.GeometrySlot:
            """
            Get an element by index.
            Args:
                index: Element index.
            Returns:
                Element value.
            """
        def __iter__(self) -> collections.abc.Iterator[uipc._native.pyuipc.geometry.GeometrySlot]:
            """
            Create an iterator over the span.
            Returns:
                iterator: Iterator over span elements.
            """
        def __len__(self) -> int:
            """
            Get the size of the span.
            Returns:
                int: Number of elements.
            """
        def __setitem__(self, index: typing.SupportsInt | typing.SupportsIndex, value: uipc._native.pyuipc.geometry.GeometrySlot) -> None:
            """
            Set an element by index.
            Args:
                index: Element index.
                value: Value to set.
            """
    def __init__(self, scene: uipc._native.pyuipc.core.Scene) -> None:
        """
        Create a SceneVisitor for a scene.
        Args:
            scene: Scene to visit.
        """
    def begin_pending(self) -> None:
        """
        Begin processing pending geometries.
        """
    def config(self) -> uipc._native.pyuipc.geometry.AttributeCollection:
        """
        Get the scene configuration.
        Returns:
            dict: Configuration dictionary.
        """
    def constitution_tabular(self) -> uipc._native.pyuipc.core.ConstitutionTabular:
        """
        Get the constitution tabular.
        Returns:
            ConstitutionTabular: Reference to constitution tabular.
        """
    def contact_tabular(self) -> uipc._native.pyuipc.core.ContactTabular:
        """
        Get the contact tabular.
        Returns:
            ContactTabular: Reference to contact tabular.
        """
    def diff_sim(self) -> DiffSimVisitor:
        """
        Get the differential simulator visitor.
        Returns:
            DiffSimVisitor: Reference to diff sim visitor.
        """
    def geometries(self) -> SceneVisitor.GeometrySlotSpan:
        """
        Get all geometries.
        Returns:
            GeometrySlotSpan: Span of geometry slots.
        """
    def get(self) -> uipc._native.pyuipc.core.Scene:
        """
        Get the scene.
        Returns:
            Scene: Scene object.
        """
    def pending_geometries(self) -> SceneVisitor.GeometrySlotSpan:
        """
        Get pending geometries.
        Returns:
            GeometrySlotSpan: Span of pending geometry slots.
        """
    def pending_rest_geometries(self) -> SceneVisitor.GeometrySlotSpan:
        """
        Get pending rest geometries.
        Returns:
            GeometrySlotSpan: Span of pending rest geometry slots.
        """
    def rest_geometries(self) -> SceneVisitor.GeometrySlotSpan:
        """
        Get rest geometries.
        Returns:
            GeometrySlotSpan: Span of rest geometry slots.
        """
    def solve_pending(self) -> None:
        """
        Solve pending geometries.
        """
class WorldVisitor:
    """
    WorldVisitor class for accessing world data from backend.
    """
    def __init__(self, world: uipc._native.pyuipc.core.World) -> None:
        """
        Create a WorldVisitor for a world.
        Args:
            world: World to visit.
        """
    def animator(self) -> AnimatorVisitor:
        """
        Get the animator visitor.
        Returns:
            AnimatorVisitor: Animator visitor.
        """
    def engine(self) -> uipc._native.pyuipc.core.Engine:
        """
        Get the engine associated with this world.
        Returns:
            Engine: Engine object.
        """
    def get(self) -> uipc._native.pyuipc.core.World:
        """
        Get the world.
        Returns:
            World: World object.
        """
    def scene(self) -> SceneVisitor:
        """
        Get the scene visitor.
        Returns:
            SceneVisitor: Scene visitor.
        """
