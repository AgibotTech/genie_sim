from __future__ import annotations
import numpy
import numpy.typing
import typing
import uipc._native.pyuipc.core
import uipc._native.pyuipc.geometry
__all__: list[str] = ['ARAP', 'AffineBodyConstitution', 'AffineBodyDrivingPrismaticJoint', 'AffineBodyDrivingRevoluteJoint', 'AffineBodyExternalBodyForce', 'AffineBodyFixedJoint', 'AffineBodyPrismaticJoint', 'AffineBodyPrismaticJointExternalForce', 'AffineBodyPrismaticJointLimit', 'AffineBodyRevoluteJoint', 'AffineBodyRevoluteJointExternalForce', 'AffineBodyRevoluteJointLimit', 'AffineBodyRod', 'AffineBodyShell', 'AffineBodySphericalJoint', 'Constraint', 'DiscreteShellBending', 'ElasticModuli', 'ElasticModuli2D', 'Empty', 'ExternalArticulationConstraint', 'FiniteElementConstitution', 'FiniteElementExternalForce', 'FiniteElementExtraConstitution', 'HookeanSpring', 'IConstitution', 'InterAffineBodyConstitution', 'InterAffineBodyExtraConstitution', 'InterPrimitiveConstitution', 'KirchhoffRodBending', 'LinearMotor', 'NeoHookeanShell', 'Particle', 'RotatingMotor', 'SoftPositionConstraint', 'SoftTransformConstraint', 'SoftVertexEdgeStitch', 'SoftVertexStitch', 'SoftVertexTriangleStitch', 'StableNeoHookean', 'StrainLimitingBaraffWitkinShell', 'StrainPlasticDiscreteShellBending', 'StressPlasticDiscreteShellBending']
class ARAP(FiniteElementConstitution):
    """
    ARAP (As-Rigid-As-Possible) constitution for elastic deformation.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default ARAP configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an ARAP constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, kappa: typing.SupportsFloat | typing.SupportsIndex = 1000000.0, mass_density: typing.SupportsFloat | typing.SupportsIndex = 1000.0) -> None:
        """
        Apply ARAP constitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            kappa: Stiffness parameter in MPa (default: 1.0 MPa).
            mass_density: Mass density (default: 1000.0).
        """
class AffineBodyConstitution(IConstitution):
    """
    AffineBodyConstitution for rigid body simulation with affine transformations.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default AffineBodyConstitution configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {'name': 'OrthoPotential'}) -> None:
        """
        Create an AffineBodyConstitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, kappa: typing.SupportsFloat | typing.SupportsIndex, mass_density: typing.SupportsFloat | typing.SupportsIndex = 1000.0) -> None:
        """
        Apply AffineBodyConstitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            kappa: Stiffness parameter.
            mass_density: Mass density (default: 1000.0).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, kappa: typing.SupportsFloat | typing.SupportsIndex, mass: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], volume: typing.SupportsFloat | typing.SupportsIndex) -> None:
        """
        Apply AffineBodyConstitution with explicit mass matrix and volume override.
        Args:
            sc: SimplicialComplex to apply to.
            kappa: Stiffness parameter.
            mass: 12x12 ABD mass matrix.
            volume: Volume of the body.
        """
    @typing.overload
    def create_proxy(self, kappa: typing.SupportsFloat | typing.SupportsIndex, mass: typing.SupportsFloat | typing.SupportsIndex, mass_center: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], inertia: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], volume: typing.SupportsFloat | typing.SupportsIndex) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create a 1-vertex proxy affine body from rigid body mass properties.
        Args:
            kappa: Stiffness parameter.
            mass: Scalar mass.
            mass_center: (3,) center of mass.
            inertia: (3,3) inertia matrix.
            volume: Volume of the body.
        Returns:
            SimplicialComplex: A single-vertex proxy geometry with ABD attributes.
        """
    @typing.overload
    def create_proxy(self, kappa: typing.SupportsFloat | typing.SupportsIndex, abd_mass: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], volume: typing.SupportsFloat | typing.SupportsIndex) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create a 1-vertex proxy affine body from a precomputed 12x12 ABD mass matrix.
        Args:
            kappa: Stiffness parameter.
            abd_mass: (12,12) ABD mass matrix.
            volume: Volume of the body.
        Returns:
            SimplicialComplex: A single-vertex proxy geometry with ABD attributes.
        """
class AffineBodyDrivingPrismaticJoint(IConstitution):
    """
    AffineBodyDrivingPrismaticJoint constitution for driving prismatic (sliding) joints between affine bodies.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default AffineBodyDrivingPrismaticJoint configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an AffineBodyDrivingPrismaticJoint.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, strength_ratio: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Create joint between two affine bodies (single-instance mode).
        edges: Every edge in the simplicial complex is treated as a joint axis.
        strength_ratio: The strength ratio of the joint constraint applied to all joints (default: 100).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Create joint between two affine bodies (multi-instance mode).
        edges: Every edge in the simplicial complex is treated as a joint axis.
        strength_ratios: List of strength ratios for each joint (one per edge).
        """
class AffineBodyDrivingRevoluteJoint(IConstitution):
    """
    AffineBodyDrivingRevoluteJoint constitution for driving revolute (hinge) joints between affine bodies.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default AffineBodyDrivingRevoluteJoint configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an AffineBodyDrivingRevoluteJoint.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, strength_ratio: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Create joint between two affine bodies (single-instance mode).
        edges: Every edge in the simplicial complex is treated as a joint axis.
        strength_ratio: The strength ratio of the joint constraint applied to all joints (default: 100).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Create joint between two affine bodies (multi-instance mode).
        edges: Every edge in the simplicial complex is treated as a joint axis.
        strength_ratios: List of strength ratios for each joint (one per edge).
        """
class AffineBodyExternalBodyForce(IConstitution):
    @staticmethod
    def default_config() -> json:
        """
        Get the default configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        ...
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, force: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[12, 1]"]) -> None:
        """
        Apply external force (12D generalized force) to affine body instances.
        
                     Args:
                         sc: SimplicialComplex representing affine body geometry
                         force: 12D generalized force vector [fx, fy, fz, f_a11, f_a12, ..., f_a33]
                                where f is 3D translational force and f_a is 9D affine force
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, force: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> None:
        """
        Apply external translational force to affine body instances.
        
                     Args:
                         sc: SimplicialComplex representing affine body geometry
                         force: 3D translational force vector (affine force = 0)
        """
class AffineBodyFixedJoint(InterAffineBodyConstitution):
    """
    AffineBodyFixedJoint constitution for fixed (rigid) joints between affine bodies.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default AffineBodyFixedJoint configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an AffineBodyFixedJoint.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, l_geo_slots: list, r_geo_slots: list, strength_ratio: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Bind fixed joint geometry to affine bodies (single-instance mode).
        sc: A SimplicialComplex with vertices representing joint attachment points.
        l_geo_slots: Left geometry slots for each joint.
        r_geo_slots: Right geometry slots for each joint.
        strength_ratio: Stiffness = strength_ratio * (BodyMassA + BodyMassB) for all joints.
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Bind fixed joint geometry to affine bodies (multi-instance mode).
        sc: A SimplicialComplex with vertices representing joint attachment points.
        l_geo_slots: Left geometry slots for each joint.
        l_instance_ids: Instance IDs for left geometries.
        r_geo_slots: Right geometry slots for each joint.
        r_instance_ids: Instance IDs for right geometries.
        strength_ratios: Strength ratios for each joint (one per vertex).
        """
    @typing.overload
    def create_geometry(self, l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create fixed joint geometry using world-space positions (computed from body transforms).
        
        Args:
            l_geo_slots: Left geometry slots for each joint.
            l_instance_ids: Instance IDs for left geometries.
            r_geo_slots: Right geometry slots for each joint.
            r_instance_ids: Instance IDs for right geometries.
            strength_ratios: Strength ratio for each joint.
        
        Returns:
            SimplicialComplex: The joint geometry mesh.
        """
    @typing.overload
    def create_geometry(self, l_positions: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], r_positions: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create fixed joint geometry using local-space attachment positions.
        
        Args:
            l_positions: Local-space attachment positions on the left body (Nx3 array).
            r_positions: Local-space attachment positions on the right body (Nx3 array).
            l_geo_slots: Left geometry slots for each joint.
            l_instance_ids: Instance IDs for left geometries.
            r_geo_slots: Right geometry slots for each joint.
            r_instance_ids: Instance IDs for right geometries.
            strength_ratios: Strength ratio for each joint.
        
        Returns:
            SimplicialComplex: The joint geometry mesh.
        """
class AffineBodyPrismaticJoint(InterAffineBodyConstitution):
    """
    AffineBodyPrismaticJoint constitution for prismatic (sliding) joints between affine bodies.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default AffineBodyPrismaticJoint configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an AffineBodyPrismaticJoint.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, l_geo_slots: list, r_geo_slots: list, strength_ratio: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Create joint between two affine bodies (single-instance mode).
        sc: Every edge in the simplicial complex is treated as a joint axis.
        l_geo_slots: List of left geometry slots for each joint.
        r_geo_slots: List of right geometry slots for each joint.
        strength_ratio: Stiffness = strength_ratio * (BodyMassA + BodyMassB) for all joints.
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Create joint between two affine bodies (multi-instance mode).
        sc: Every edge in the simplicial complex is treated as a joint axis.
        l_geo_slots: List of left geometry slots for each joint.
        l_instance_ids: List of instance IDs for left geometries.
        r_geo_slots: List of right geometry slots for each joint.
        r_instance_ids: List of instance IDs for right geometries.
        strength_ratios: List of strength ratios for each joint (one per edge).
        """
    @typing.overload
    def create_geometry(self, position0s: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], position1s: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create prismatic joint geometry using world-space axis endpoints.
        
        Args:
            position0s: World positions of the first axis endpoint for each joint (Nx3 array).
            position1s: World positions of the second axis endpoint for each joint (Nx3 array).
            l_geo_slots: Left geometry slots for each joint.
            l_instance_ids: Instance IDs for left geometries.
            r_geo_slots: Right geometry slots for each joint.
            r_instance_ids: Instance IDs for right geometries.
            strength_ratios: Strength ratio for each joint.
        
        Returns:
            SimplicialComplex: The joint geometry mesh.
        """
    @typing.overload
    def create_geometry(self, l_position0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], l_position1: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], r_position0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], r_position1: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create prismatic joint geometry using local-space axis endpoints.
        
        Args:
            l_position0: Local positions of the first axis endpoint on the left body (Nx3 array).
            l_position1: Local positions of the second axis endpoint on the left body (Nx3 array).
            r_position0: Local positions of the first axis endpoint on the right body (Nx3 array).
            r_position1: Local positions of the second axis endpoint on the right body (Nx3 array).
            l_geo_slots: Left geometry slots for each joint.
            l_instance_ids: Instance IDs for left geometries.
            r_geo_slots: Right geometry slots for each joint.
            r_instance_ids: Instance IDs for right geometries.
            strength_ratios: Strength ratio for each joint.
        
        Returns:
            SimplicialComplex: The joint geometry mesh.
        """
class AffineBodyPrismaticJointExternalForce(Constraint):
    """
    Applies external force along the prismatic joint axis between two connected affine bodies.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an AffineBodyPrismaticJointExternalForce.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, force: typing.SupportsFloat | typing.SupportsIndex = 0.0) -> None:
        """
        Apply uniform external force along prismatic joint axis to all joints.
        sc: Simplicial complex with edges representing the joints (must have AffineBodyPrismaticJoint applied).
        force: Scalar force value applied to all joints (default: 0).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, forces: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Apply per-joint external forces along prismatic joint axis.
        sc: Simplicial complex with edges representing the joints (must have AffineBodyPrismaticJoint applied).
        forces: List of scalar force values (one per edge).
        """
class AffineBodyPrismaticJointLimit(InterAffineBodyExtraConstitution):
    """
    AffineBodyPrismaticJointLimit cubic penalty limit on prismatic joint value.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get default configuration.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an AffineBodyPrismaticJointLimit.
        Args:
            config: Configuration dictionary (optional).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, lower: typing.SupportsFloat | typing.SupportsIndex, upper: typing.SupportsFloat | typing.SupportsIndex, strength: typing.SupportsFloat | typing.SupportsIndex = 1.0) -> None:
        """
        Apply scalar lower/upper/strength to all joint edges.
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, lowers: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], uppers: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], strengths: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Apply per-edge lower/upper/strength vectors.
        """
class AffineBodyRevoluteJoint(InterAffineBodyConstitution):
    """
    AffineBodyRevoluteJoint constitution for revolute (hinge) joints between affine bodies.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default AffineBodyRevoluteJoint configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an AffineBodyRevoluteJoint.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, l_geo_slots: list, r_geo_slots: list, strength_ratio: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Create joint between two affine bodies (single-instance mode).
        sc: Every edge in the simplicial complex is treated as a joint axis.
        l_geo_slots: List of left geometry slots for each joint.
        r_geo_slots: List of right geometry slots for each joint.
        strength_ratio: Stiffness = strength_ratio * (BodyMassA + BodyMassB) for all joints.
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Create joint between two affine bodies (multi-instance mode).
        sc: Every edge in the simplicial complex is treated as a joint axis.
        l_geo_slots: List of left geometry slots for each joint.
        l_instance_ids: List of instance IDs for left geometries.
        r_geo_slots: List of right geometry slots for each joint.
        r_instance_ids: List of instance IDs for right geometries.
        strength_ratios: List of strength ratios for each joint (one per edge).
        """
    @typing.overload
    def create_geometry(self, position0s: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], position1s: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create revolute joint geometry using world-space axis endpoints.
        
        Args:
            position0s: World positions of the first axis endpoint for each joint (Nx3 array).
            position1s: World positions of the second axis endpoint for each joint (Nx3 array).
            l_geo_slots: Left geometry slots for each joint.
            l_instance_ids: Instance IDs for left geometries.
            r_geo_slots: Right geometry slots for each joint.
            r_instance_ids: Instance IDs for right geometries.
            strength_ratios: Strength ratio for each joint.
        
        Returns:
            SimplicialComplex: The joint geometry mesh.
        """
    @typing.overload
    def create_geometry(self, l_position0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], l_position1: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], r_position0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], r_position1: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create revolute joint geometry using local-space axis endpoints.
        
        Args:
            l_position0: Local positions of the first axis endpoint on the left body (Nx3 array).
            l_position1: Local positions of the second axis endpoint on the left body (Nx3 array).
            r_position0: Local positions of the first axis endpoint on the right body (Nx3 array).
            r_position1: Local positions of the second axis endpoint on the right body (Nx3 array).
            l_geo_slots: Left geometry slots for each joint.
            l_instance_ids: Instance IDs for left geometries.
            r_geo_slots: Right geometry slots for each joint.
            r_instance_ids: Instance IDs for right geometries.
            strength_ratios: Strength ratio for each joint.
        
        Returns:
            SimplicialComplex: The joint geometry mesh.
        """
class AffineBodyRevoluteJointExternalForce(Constraint):
    """
    Applies external torque around the revolute joint axis between two connected affine bodies.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an AffineBodyRevoluteJointExternalForce.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, torque: typing.SupportsFloat | typing.SupportsIndex = 0.0) -> None:
        """
        Apply uniform external torque around revolute joint axis to all joints.
        sc: Simplicial complex with edges representing the joints (must have AffineBodyRevoluteJoint applied).
        torque: Scalar torque value applied to all joints (default: 0).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, torques: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Apply per-joint external torques around revolute joint axis.
        sc: Simplicial complex with edges representing the joints (must have AffineBodyRevoluteJoint applied).
        torques: List of scalar torque values (one per edge).
        """
class AffineBodyRevoluteJointLimit(InterAffineBodyExtraConstitution):
    """
    AffineBodyRevoluteJointLimit cubic penalty limit on revolute joint angle.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get default configuration.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an AffineBodyRevoluteJointLimit.
        Args:
            config: Configuration dictionary (optional).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, lower: typing.SupportsFloat | typing.SupportsIndex, upper: typing.SupportsFloat | typing.SupportsIndex, strength: typing.SupportsFloat | typing.SupportsIndex = 1.0) -> None:
        """
        Apply scalar lower/upper/strength to all joint edges.
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, lowers: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], uppers: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], strengths: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Apply per-edge lower/upper/strength vectors.
        """
class AffineBodyRod(AffineBodyConstitution):
    """
    Codimensional 1D (rod) affine body constitution.
    
    Convenience subclass of AffineBodyConstitution for edge meshes (polylines)
    treated as thin rods with a circular cross-section of a given radius.
    """
    def __init__(self, config: json = {'name': 'OrthoPotential'}) -> None:
        """
        Create an AffineBodyRod.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, kappa: typing.SupportsFloat | typing.SupportsIndex, mass_density: typing.SupportsFloat | typing.SupportsIndex = 1000.0, thickness: typing.SupportsFloat | typing.SupportsIndex = 0.01) -> None:
        """
        Apply the rod constitution to a 1D simplicial complex.
        Args:
            sc: Edge mesh (dim == 1).
            kappa: Stiffness parameter for shape energy.
            mass_density: Volume mass density in kg/m^3 (default: 1000.0).
            thickness: Rod cross-section radius r; cross-section area = pi * r^2 (default: 0.01).
        """
class AffineBodyShell(AffineBodyConstitution):
    """
    Codimensional 2D (shell) affine body constitution.
    
    Convenience subclass of AffineBodyConstitution for open triangle meshes
    treated as thin shells with a given thickness.
    """
    def __init__(self, config: json = {'name': 'OrthoPotential'}) -> None:
        """
        Create an AffineBodyShell.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, kappa: typing.SupportsFloat | typing.SupportsIndex, mass_density: typing.SupportsFloat | typing.SupportsIndex = 1000.0, thickness: typing.SupportsFloat | typing.SupportsIndex = 0.01) -> None:
        """
        Apply the shell constitution to a 2D simplicial complex.
        Args:
            sc: Triangle mesh (dim == 2).
            kappa: Stiffness parameter for shape energy.
            mass_density: Volume mass density in kg/m^3 (default: 1000.0).
            thickness: Shell thickness radius r; effective slab thickness = 2r (default: 0.01).
        """
class AffineBodySphericalJoint(InterAffineBodyConstitution):
    """
    AffineBodySphericalJoint constitution for ball-and-socket joints between affine bodies.
    Constrains only the translational degrees of freedom (anchor points coincide),
    while allowing free relative rotation.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default AffineBodySphericalJoint configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an AffineBodySphericalJoint.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, l_geo_slots: list, r_geo_slots: list, strength_ratio: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Bind spherical joint geometry to affine bodies (single-instance mode).
        sc: A SimplicialComplex with vertices representing joint anchor points.
        l_geo_slots: Left geometry slots for each joint.
        r_geo_slots: Right geometry slots for each joint.
        strength_ratio: Stiffness = strength_ratio * (BodyMassA + BodyMassB) for all joints.
        """
    @typing.overload
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Bind spherical joint geometry to affine bodies (multi-instance mode).
        sc: A SimplicialComplex with vertices representing joint anchor points.
        l_geo_slots: Left geometry slots for each joint.
        l_instance_ids: Instance IDs for left geometries.
        r_geo_slots: Right geometry slots for each joint.
        r_instance_ids: Instance IDs for right geometries.
        strength_ratios: Strength ratios for each joint (one per vertex).
        """
    @typing.overload
    def create_geometry(self, positions: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create spherical joint geometry using world-space anchor positions.
        
        Args:
            positions: World positions of the anchor point for each joint (Nx3 array).
            l_geo_slots: Left geometry slots for each joint.
            l_instance_ids: Instance IDs for left geometries.
            r_geo_slots: Right geometry slots for each joint.
            r_instance_ids: Instance IDs for right geometries.
            strength_ratios: Strength ratio for each joint.
        
        Returns:
            SimplicialComplex: The joint geometry mesh.
        """
    @typing.overload
    def create_geometry(self, l_positions: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], r_positions: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], l_geo_slots: list, l_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], r_geo_slots: list, r_instance_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], strength_ratios: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create spherical joint geometry using local-space anchor positions.
        
        Args:
            l_positions: Local-space anchor positions on the left body (Nx3 array).
            r_positions: Local-space anchor positions on the right body (Nx3 array).
            l_geo_slots: Left geometry slots for each joint.
            l_instance_ids: Instance IDs for left geometries.
            r_geo_slots: Right geometry slots for each joint.
            r_instance_ids: Instance IDs for right geometries.
            strength_ratios: Strength ratio for each joint.
        
        Returns:
            SimplicialComplex: The joint geometry mesh.
        """
class Constraint(IConstitution):
    """
    Constraint base class for simulation constraints.
    """
class DiscreteShellBending(FiniteElementExtraConstitution):
    """
    DiscreteShellBending constitution for shell bending energy.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default DiscreteShellBending configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a DiscreteShellBending constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, bending_stiffness: typing.SupportsFloat | typing.SupportsIndex = 100000.0) -> None:
        """
        Apply DiscreteShellBending constitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            bending_stiffness: Bending stiffness in kPa (default: 100.0 kPa).
        """
class ElasticModuli:
    """
    ElasticModuli class for elastic material parameters (Lame parameters).
    """
    @staticmethod
    def lame(lambda_: typing.SupportsFloat | typing.SupportsIndex, mu: typing.SupportsFloat | typing.SupportsIndex) -> ElasticModuli:
        """
        Create elastic moduli from Lame parameters.
        Args:
            lambda_: First Lame parameter.
            mu: Second Lame parameter (shear modulus).
        Returns:
            ElasticModuli: Elastic moduli object.
        """
    @staticmethod
    def youngs_poisson(E: typing.SupportsFloat | typing.SupportsIndex, nu: typing.SupportsFloat | typing.SupportsIndex) -> ElasticModuli:
        """
        Create elastic moduli from Young's modulus and Poisson's ratio.
        Args:
            E: Young's modulus.
            nu: Poisson's ratio.
        Returns:
            ElasticModuli: Elastic moduli object.
        """
    @staticmethod
    def youngs_shear(E: typing.SupportsFloat | typing.SupportsIndex, G: typing.SupportsFloat | typing.SupportsIndex) -> ElasticModuli:
        """
        Create elastic moduli from Young's modulus and shear modulus.
        Args:
            E: Young's modulus.
            G: Shear modulus.
        Returns:
            ElasticModuli: Elastic moduli object.
        """
    def __repr__(self) -> str:
        """
        String representation of elastic moduli.
        """
    def lambda_(self) -> float:
        """
        Get the first Lame parameter (lambda).
        Returns:
            float: First Lame parameter.
        """
    def mu(self) -> float:
        """
        Get the second Lame parameter (mu, shear modulus).
        Returns:
            float: Second Lame parameter.
        """
class ElasticModuli2D:
    """
    ElasticModuli2D class for codim 2D elastic material parameters (Lame parameters).
    """
    @staticmethod
    def lame(lambda_: typing.SupportsFloat | typing.SupportsIndex, mu: typing.SupportsFloat | typing.SupportsIndex) -> ElasticModuli2D:
        """
        Create 2D elastic moduli from Lame parameters.
        Args:
            lambda_: First Lame parameter.
            mu: Second Lame parameter (shear modulus).
        Returns:
            ElasticModuli2D: 2D Elastic moduli object.
        """
    @staticmethod
    def youngs_poisson(E: typing.SupportsFloat | typing.SupportsIndex, nu: typing.SupportsFloat | typing.SupportsIndex) -> ElasticModuli2D:
        """
        Create 2D elastic moduli from Young's modulus and Poisson's ratio.
        Args:
            E: Young's modulus.
            nu: Poisson's ratio.
        Returns:
            ElasticModuli2D: 2D Elastic moduli object.
        """
    @staticmethod
    def youngs_shear(E: typing.SupportsFloat | typing.SupportsIndex, G: typing.SupportsFloat | typing.SupportsIndex) -> ElasticModuli2D:
        """
        Create 2D elastic moduli from Young's modulus and shear modulus.
        Args:
            E: Young's modulus.
            G: Shear modulus.
        Returns:
            ElasticModuli2D: 2D Elastic moduli object.
        """
    def __repr__(self) -> str:
        """
        String representation of 2D elastic moduli.
        """
    def lambda_(self) -> float:
        """
        Get the first Lame parameter (lambda).
        Returns:
            float: First Lame parameter.
        """
    def mu(self) -> float:
        """
        Get the second Lame parameter (mu, shear modulus).
        Returns:
            float: Second Lame parameter.
        """
class Empty(FiniteElementConstitution):
    """
    Empty constitution (no material properties, used for mass-only elements).
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default Empty configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an Empty constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, mass_density: typing.SupportsFloat | typing.SupportsIndex = 1000.0, thickness: typing.SupportsFloat | typing.SupportsIndex = 0.01) -> None:
        """
        Apply Empty constitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            mass_density: Mass density (default: 1000.0).
            thickness: Thickness in meters (default: 0.01 m).
        """
class ExternalArticulationConstraint(Constraint):
    """
    External articulation constraint for incorporating external kinetic energy into the IPC system.
    
    Controls motion of affine bodies by prescribing articulation DOFs (joint positions, angles, etc.).
    Kinetic energy: K = 1/2(delta_theta - delta_theta_tilde)^T M^t (delta_theta - delta_theta_tilde).
    
    Users must provide M^t (effective mass matrix) and delta_theta_tilde (predicted joint DOF) through
    animator callback. Works with AffineBodyRevoluteJoint and AffineBodyPrismaticJoint.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default ExternalArticulationConstraint configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create an ExternalArticulationConstraint.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def create_geometry(self, joint_geos: list) -> uipc._native.pyuipc.geometry.Geometry:
        """
        Create geometry for external articulation joints.
        
        Creates geometry with joint attributes (geo_id, index, delta_theta_tilde, delta_theta)
        and joint-joint mass attributes. All joints use index 0 by default.
        
        Args:
            joint_geos: List of geometry slots containing joint information.
        Returns:
            Geometry: Created geometry with joint constraint data.
        """
    @typing.overload
    def create_geometry(self, joint_geos: list, indices: typing.Annotated[numpy.typing.ArrayLike, numpy.int32]) -> uipc._native.pyuipc.geometry.Geometry:
        """
        Create geometry for external articulation joints with specified indices.
        
        Same as single-parameter version but allows selecting specific joints from each slot.
        
        Args:
            joint_geos: List of geometry slots containing joint information.
            indices: List of indices specifying which joint to use from each slot. Must match joint_geos size.
        Returns:
            Geometry: Created geometry with joint constraint data.
        """
class FiniteElementConstitution(IConstitution):
    """
    FiniteElementConstitution base class for finite element material models.
    """
class FiniteElementExternalForce(IConstitution):
    @staticmethod
    def default_config() -> json:
        ...
    def __init__(self, config: json = {}) -> None:
        ...
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, force: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> None:
        """
        Apply external force (3D) to finite element vertices.
        
                     Args:
                         sc: SimplicialComplex representing finite element geometry
                         force: 3D force vector applied uniformly to all vertices
        """
class FiniteElementExtraConstitution(IConstitution):
    """
    FiniteElementExtraConstitution base class for extra finite element constitutions (e.g., bending).
    """
class HookeanSpring(FiniteElementConstitution):
    """
    HookeanSpring constitution for linear elastic spring behavior.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default HookeanSpring configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a HookeanSpring constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, moduli: typing.SupportsFloat | typing.SupportsIndex = 40000000.0, mass_density: typing.SupportsFloat | typing.SupportsIndex = 1000.0, thickness: typing.SupportsFloat | typing.SupportsIndex = 0.01) -> None:
        """
        Apply HookeanSpring constitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            moduli: Elastic moduli in MPa (default: 40.0 MPa).
            mass_density: Mass density (default: 1000.0).
            thickness: Thickness in meters (default: 0.01 m).
        """
class IConstitution:
    """
    IConstitution interface for all constitution types (material models and constraints).
    """
    def name(self) -> str:
        """
        Get the constitution name.
        Returns:
            str: Constitution name.
        """
    def type(self) -> str:
        """
        Get the constitution type name.
        Returns:
            str: Constitution type name.
        """
    def uid(self) -> int:
        """
        Get the constitution UID (unique identifier).
        Returns:
            int: Constitution UID.
        """
class InterAffineBodyConstitution(IConstitution):
    """
    InterAffineBodyConstitution base class for constitutions between affine bodies (e.g., joints).
    """
class InterAffineBodyExtraConstitution(IConstitution):
    """
    InterAffineBodyExtraConstitution base class for extra constitutions on inter-affine-body geometries.
    """
class InterPrimitiveConstitution(IConstitution):
    """
    InterPrimitiveConstitution base class for constitutions between primitives (e.g., stitching).
    """
class KirchhoffRodBending(FiniteElementExtraConstitution):
    """
    KirchhoffRodBending constitution for rod bending energy.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default KirchhoffRodBending configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a KirchhoffRodBending constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, E: typing.SupportsFloat | typing.SupportsIndex = 10000000.0) -> None:
        """
        Apply KirchhoffRodBending constitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            E: Young's modulus in MPa (default: 10.0 MPa).
        """
class LinearMotor(Constraint):
    """
    LinearMotor constraint for applying linear motion to affine bodies.
    """
    @staticmethod
    def animate(sc: uipc._native.pyuipc.geometry.SimplicialComplex, dt: typing.SupportsFloat | typing.SupportsIndex) -> None:
        """
        Animate the linear motor for a time step.
        Args:
            sc: SimplicialComplex to animate.
            dt: Time step.
        """
    @staticmethod
    def default_config() -> json:
        """
        Get the default LinearMotor configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a LinearMotor.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, strength: typing.SupportsFloat | typing.SupportsIndex = 100.0, motor_axis: typing.Annotated[numpy.typing.ArrayLike, numpy.float64] = ..., motor_vel: typing.SupportsFloat | typing.SupportsIndex = 1.0) -> None:
        """
        Apply linear motor to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            strength: Motor strength (default: 100.0).
            motor_axis: Motion direction vector (default: -Z-axis).
            motor_vel: Linear velocity (default: 1.0).
        """
class NeoHookeanShell(FiniteElementConstitution):
    """
    NeoHookeanShell constitution for neo-Hookean shell material.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default NeoHookeanShell configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a NeoHookeanShell constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, moduli: ElasticModuli2D = ..., mass_density: typing.SupportsFloat | typing.SupportsIndex = 200.0, thickness: typing.SupportsFloat | typing.SupportsIndex = 0.001) -> None:
        """
        Apply NeoHookeanShell constitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            moduli: ElasticModuli2D (default: Young's modulus 1.0 MPa, Poisson's ratio 0.49).
            mass_density: Mass density (default: 200.0).
            thickness: Shell thickness in meters (default: 0.001 m).
        """
class Particle(FiniteElementConstitution):
    """
    Particle constitution for point-mass simulation.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default Particle configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a Particle constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, mass_density: typing.SupportsFloat | typing.SupportsIndex = 1000.0, thickness: typing.SupportsFloat | typing.SupportsIndex = 0.01) -> None:
        """
        Apply Particle constitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            mass_density: Mass density (default: 1000.0).
            thickness: Thickness in meters (default: 0.01 m).
        """
class RotatingMotor(Constraint):
    """
    RotatingMotor constraint for applying rotational motion to affine bodies.
    """
    @staticmethod
    def animate(sc: uipc._native.pyuipc.geometry.SimplicialComplex, dt: typing.SupportsFloat | typing.SupportsIndex) -> None:
        """
        Animate the rotating motor for a time step.
        Args:
            sc: SimplicialComplex to animate.
            dt: Time step.
        """
    @staticmethod
    def default_config() -> json:
        """
        Get the default RotatingMotor configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a RotatingMotor.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, strength: typing.SupportsFloat | typing.SupportsIndex = 100.0, motor_axis: typing.Annotated[numpy.typing.ArrayLike, numpy.float64] = ..., motor_rot_vel: typing.SupportsFloat | typing.SupportsIndex = 6.283185307179586) -> None:
        """
        Apply rotating motor to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            strength: Motor strength (default: 100.0).
            motor_axis: Rotation axis vector (default: X-axis).
            motor_rot_vel: Rotational velocity in rad/s (default: 2π).
        """
class SoftPositionConstraint(Constraint):
    """
    SoftPositionConstraint for constraining vertex positions with soft (penalty-based) constraints.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default SoftPositionConstraint configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a SoftPositionConstraint.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, strength_rate: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Apply soft position constraint to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            strength_rate: Constraint strength rate (default: 100.0).
        """
class SoftTransformConstraint(Constraint):
    """
    SoftTransformConstraint for constraining affine transforms with soft (penalty-based) constraints.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default SoftTransformConstraint configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a SoftTransformConstraint.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, strength_ratio: typing.Annotated[numpy.typing.ArrayLike, numpy.float64] = ...) -> None:
        """
        Apply soft transform constraint to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            strength_ratio: 2D vector (eta_p, eta_a), where eta_p controls center-of-mass
                translation strength and eta_a controls rotation/deformation-about-CM strength
                (default: [100.0, 100]).
        """
class SoftVertexEdgeStitch(InterPrimitiveConstitution):
    """
    SoftVertexEdgeStitch: (vertex, edge) pairs form triangles with NeoHookeanShell energy. UID 29.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default configuration.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a SoftVertexEdgeStitch constitution.
        """
    @typing.overload
    def create_geometry(self, aim_geo_slots: tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot], rest_geo_slots: tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot], stitched_vert_edge_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], moduli: ElasticModuli2D = ..., thickness: typing.SupportsFloat | typing.SupportsIndex = 0.001, min_separate_distance: typing.SupportsFloat | typing.SupportsIndex = 0.001) -> uipc._native.pyuipc.geometry.Geometry:
        """
        Create stitch geometry from explicit (vertex_index, edge_index) pairs.
        """
    @typing.overload
    def create_geometry(self, aim_geo_slots: tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot], rest_geo_slots: tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot], pair_geometry: uipc._native.pyuipc.geometry.Geometry, moduli: ElasticModuli2D = ..., thickness: typing.SupportsFloat | typing.SupportsIndex = 0.001, min_separate_distance: typing.SupportsFloat | typing.SupportsIndex = 0.001) -> uipc._native.pyuipc.geometry.Geometry:
        """
        Create stitch geometry from the Geometry returned by closest_vertex_edge_pairs.
        """
class SoftVertexStitch(InterPrimitiveConstitution):
    """
    SoftVertexStitch constitution for stitching vertices between geometries with soft constraints.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default SoftVertexStitch configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a SoftVertexStitch constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def create_geometry(self, aim_geo_slots: tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot], stitched_vert_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], kappa: typing.SupportsFloat | typing.SupportsIndex = 1000000.0, rest_length: typing.SupportsFloat | typing.SupportsIndex = 0.0) -> uipc._native.pyuipc.geometry.Geometry:
        """
        Create geometry for vertex stitching.
        Args:
            aim_geo_slots: Tuple of geometry slots to stitch.
            stitched_vert_ids: Array of vertex ID pairs [geometry0_vert, geometry1_vert] to stitch.
            kappa: Stitching stiffness (default: 1e6).
            rest_length: Rest length of the spring (default: 0.0). When 0, the singularity-free
                harmonic energy E=0.5*k*||x-y||^2 is used.
        Returns:
            Geometry: Created stitching geometry.
        """
    @typing.overload
    def create_geometry(self, aim_geo_slots: tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot], stitched_vert_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.float64], contact_elements: tuple[uipc._native.pyuipc.core.ContactElement, uipc._native.pyuipc.core.ContactElement], kappa: typing.SupportsFloat | typing.SupportsIndex = 1000000.0, rest_length: typing.SupportsFloat | typing.SupportsIndex = 0.0) -> uipc._native.pyuipc.geometry.Geometry:
        """
        Create geometry for vertex stitching with contact elements.
        Args:
            aim_geo_slots: Tuple of geometry slots to stitch.
            stitched_vert_ids: Array of vertex ID pairs [geometry0_vert, geometry1_vert] to stitch.
            contact_elements: Tuple of two contact element objects.
            kappa: Stitching stiffness (default: 1e6).
            rest_length: Rest length of the spring (default: 0.0). When 0, the singularity-free
                harmonic energy E=0.5*k*||x-y||^2 is used.
        Returns:
            Created stitching geometry.
        """
class SoftVertexTriangleStitch(InterPrimitiveConstitution):
    """
    SoftVertexTriangleStitch: (vertex, triangle) pairs form tetrahedra with StableNeoHookean energy. UID 30.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default configuration.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a SoftVertexTriangleStitch constitution.
        """
    @typing.overload
    def create_geometry(self, aim_geo_slots: tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot], rest_geo_slots: tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot], stitched_vert_tri_ids: typing.Annotated[numpy.typing.ArrayLike, numpy.int32], moduli: ElasticModuli = ..., min_separate_distance: typing.SupportsFloat | typing.SupportsIndex = 0.001) -> uipc._native.pyuipc.geometry.Geometry:
        """
        Create stitch geometry from explicit (vertex_index, triangle_index) pairs.
            When a tet is degenerate, rest vertex is offset by min_separate_distance (default 1 mm).
        Args:
            aim_geo_slots: Tuple (vertex_provider_slot, triangle_provider_slot).
            rest_geo_slots: Tuple of rest geometry slots for Dm_inv/rest_volume.
            stitched_vert_tri_ids: Nx2 array [vertex_id, triangle_id] per pair.
            moduli: ElasticModuli (default: Young's modulus 120 kPa, Poisson's ratio 0.49).
            min_separate_distance: Distance (m) when tet is degenerate. Default 0.001 (1 mm).
        Returns:
            Geometry: Stitch geometry.
        """
    @typing.overload
    def create_geometry(self, aim_geo_slots: tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot], rest_geo_slots: tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot], pair_geometry: uipc._native.pyuipc.geometry.Geometry, moduli: ElasticModuli = ..., min_separate_distance: typing.SupportsFloat | typing.SupportsIndex = 0.001) -> uipc._native.pyuipc.geometry.Geometry:
        """
        Create stitch geometry from the Geometry returned by closest_vertex_triangle_pairs.
            When a tet is degenerate, uses min_separate_distance (default 1 mm). For per-instance values, add instance attribute 'min_separate_distance' (Float) to pair_geometry and modify it.
        Args:
            aim_geo_slots: Tuple (vertex_provider_slot, triangle_provider_slot).
            rest_geo_slots: Tuple of rest geometry slots.
            pair_geometry: Geometry with instances holding topo Vector2i (vertex_index, triangle_index).
            moduli: ElasticModuli (default: Young's modulus 120 kPa, Poisson's ratio 0.49).
            min_separate_distance: Distance (m) when tet is degenerate. Default 0.001 (1 mm).
        Returns:
            Geometry: Stitch geometry.
        """
class StableNeoHookean(FiniteElementConstitution):
    """
    StableNeoHookean constitution for stable neo-Hookean hyperelastic material.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default StableNeoHookean configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a StableNeoHookean constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, moduli: ElasticModuli = ..., mass_density: typing.SupportsFloat | typing.SupportsIndex = 1000.0) -> None:
        """
        Apply StableNeoHookean constitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            moduli: ElasticModuli (default: Young's modulus 120.0 kPa, Poisson's ratio 0.49).
            mass_density: Mass density (default: 1000.0).
        """
class StrainLimitingBaraffWitkinShell(FiniteElementConstitution):
    """
    StrainLimitingBaraffWitkinShell constitution with strain limiting (Baraff-Witkin method).
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default StrainLimitingBaraffWitkinShell configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a StrainLimitingBaraffWitkinShell constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, moduli: ElasticModuli2D = ..., mass_density: typing.SupportsFloat | typing.SupportsIndex = 200.0, thickness: typing.SupportsFloat | typing.SupportsIndex = 0.001) -> None:
        """
        Apply StrainLimitingBaraffWitkinShell constitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            moduli: ElasticModuli (default: Young's modulus 1.0 MPa, Poisson's ratio 0.49).
            mass_density: Mass density (default: 200.0).
            thickness: Shell thickness in meters (default: 0.001 m).
        """
class StrainPlasticDiscreteShellBending(FiniteElementExtraConstitution):
    """
    StrainPlasticDiscreteShellBending constitution for shell bending with strain-threshold plastic rest-angle evolution.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default StrainPlasticDiscreteShellBending configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a StrainPlasticDiscreteShellBending constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, bending_stiffness: typing.SupportsFloat | typing.SupportsIndex, yield_threshold: typing.SupportsFloat | typing.SupportsIndex, hardening_modulus: typing.SupportsFloat | typing.SupportsIndex = 0.0) -> None:
        """
        Apply StrainPlasticDiscreteShellBending constitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            bending_stiffness: Bending stiffness in kPa.
            yield_threshold: Yield threshold on dihedral angle deviation.
            hardening_modulus: Linear hardening modulus. Use 0.0 for perfect plasticity.
        """
class StressPlasticDiscreteShellBending(FiniteElementExtraConstitution):
    """
    StressPlasticDiscreteShellBending constitution for stress-based ECI shell bending plasticity.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default StressPlasticDiscreteShellBending configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {}) -> None:
        """
        Create a StressPlasticDiscreteShellBending constitution.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def apply_to(self, sc: uipc._native.pyuipc.geometry.SimplicialComplex, bending_stiffness: typing.SupportsFloat | typing.SupportsIndex, yield_stress: typing.SupportsFloat | typing.SupportsIndex, hardening_modulus: typing.SupportsFloat | typing.SupportsIndex = 0.0) -> None:
        """
        Apply StressPlasticDiscreteShellBending constitution to a simplicial complex.
        Args:
            sc: SimplicialComplex to apply to.
            bending_stiffness: Bending stiffness in kPa.
            yield_stress: Yield stress on the generalized bending moment.
            hardening_modulus: Isotropic hardening modulus in stress space. Use 0.0 for perfect plasticity.
        """
