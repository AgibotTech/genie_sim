"""
Libuipc Python Binding
"""
from __future__ import annotations
import collections.abc
import numpy
import numpy.typing
import typing
from uipc._native.pyuipc.core import Animation
from uipc._native.pyuipc.core import Engine
from uipc._native.pyuipc.core import Scene
from uipc._native.pyuipc.core import SceneIO
from uipc._native.pyuipc.core import World
from . import backend
from . import builtin
from . import constitution
from . import core
from . import diff_sim
from . import geometry
from . import unit
from . import usd
__all__: list[str] = ['AngleAxis', 'Animation', 'Engine', 'Exception', 'Float', 'I32', 'I64', 'IndexT', 'Logger', 'Matrix12x12', 'Matrix2x2', 'Matrix3x3', 'Matrix4x4', 'Matrix6x6', 'Matrix9x9', 'Quaternion', 'ResidentThread', 'Scene', 'SceneIO', 'SizeT', 'Timer', 'Transform', 'U32', 'U64', 'Vector12', 'Vector2', 'Vector3', 'Vector4', 'Vector6', 'Vector9', 'World', 'backend', 'builtin', 'config', 'constitution', 'core', 'default_config', 'diff_sim', 'geometry', 'init', 'unit', 'usd', 'view']
class AngleAxis:
    """
    AngleAxis class for representing rotations as an angle-axis pair.
    """
    @staticmethod
    def Identity() -> AngleAxis:
        """
        Create an identity angle-axis (no rotation).
        Returns:
            AngleAxis: Identity angle-axis.
        """
    @typing.overload
    def __init__(self, angle: typing.SupportsFloat | typing.SupportsIndex, axis: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Create an angle-axis from an angle and axis vector.
        Args:
            angle: Rotation angle in radians.
            axis: 3D axis vector (will be normalized).
        """
    @typing.overload
    def __init__(self, quaternion: Quaternion) -> None:
        """
        Create an angle-axis from a quaternion.
        Args:
            quaternion: Quaternion to convert.
        """
    @typing.overload
    def __mul__(self, other: AngleAxis) -> Quaternion:
        """
        Multiply two angle-axis rotations (returns quaternion).
        Args:
            other: Another angle-axis.
        Returns:
            Quaternion: Result of rotation composition.
        """
    @typing.overload
    def __mul__(self, quaternion: Quaternion) -> Quaternion:
        """
        Multiply angle-axis by quaternion.
        Args:
            quaternion: Quaternion to multiply with.
        Returns:
            Quaternion: Result of multiplication.
        """
    def angle(self) -> float:
        """
        Get the rotation angle.
        Returns:
            float: Rotation angle in radians.
        """
    def axis(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get the rotation axis.
        Returns:
            numpy.ndarray: 3D axis vector.
        """
class Exception(Exception):
    pass
class Float:
    """
    Type wrapper for scalar values.
    """
    @staticmethod
    def One() -> float:
        """
        Get one value.
        Returns:
            Scalar: One value.
        """
    @staticmethod
    def Value(value: typing.SupportsFloat | typing.SupportsIndex) -> float:
        """
        Create a scalar value.
        Args:
            value: Scalar value.
        Returns:
            Scalar: The value.
        """
    @staticmethod
    def Zero() -> float:
        """
        Get zero value.
        Returns:
            Scalar: Zero value.
        """
    @staticmethod
    def size_bytes() -> int:
        """
        Get the size in bytes.
        Returns:
            int: Size in bytes.
        """
class I32:
    """
    Type wrapper for scalar values.
    """
    @staticmethod
    def One() -> int:
        """
        Get one value.
        Returns:
            Scalar: One value.
        """
    @staticmethod
    def Value(value: typing.SupportsInt | typing.SupportsIndex) -> int:
        """
        Create a scalar value.
        Args:
            value: Scalar value.
        Returns:
            Scalar: The value.
        """
    @staticmethod
    def Zero() -> int:
        """
        Get zero value.
        Returns:
            Scalar: Zero value.
        """
    @staticmethod
    def size_bytes() -> int:
        """
        Get the size in bytes.
        Returns:
            int: Size in bytes.
        """
class I64:
    """
    Type wrapper for scalar values.
    """
    @staticmethod
    def One() -> int:
        """
        Get one value.
        Returns:
            Scalar: One value.
        """
    @staticmethod
    def Value(value: typing.SupportsInt | typing.SupportsIndex) -> int:
        """
        Create a scalar value.
        Args:
            value: Scalar value.
        Returns:
            Scalar: The value.
        """
    @staticmethod
    def Zero() -> int:
        """
        Get zero value.
        Returns:
            Scalar: Zero value.
        """
    @staticmethod
    def size_bytes() -> int:
        """
        Get the size in bytes.
        Returns:
            int: Size in bytes.
        """
class IndexT:
    """
    Type wrapper for scalar values.
    """
    @staticmethod
    def One() -> int:
        """
        Get one value.
        Returns:
            Scalar: One value.
        """
    @staticmethod
    def Value(value: typing.SupportsInt | typing.SupportsIndex) -> int:
        """
        Create a scalar value.
        Args:
            value: Scalar value.
        Returns:
            Scalar: The value.
        """
    @staticmethod
    def Zero() -> int:
        """
        Get zero value.
        Returns:
            Scalar: Zero value.
        """
    @staticmethod
    def size_bytes() -> int:
        """
        Get the size in bytes.
        Returns:
            int: Size in bytes.
        """
class Logger:
    """
    Logger class for logging messages at different severity levels.
    """
    class Level:
        """
        Logging level enumeration.
        
        Members:
        
          Trace
        
          Debug
        
          Info
        
          Warn
        
          Error
        
          Critical
        """
        Critical: typing.ClassVar[Logger.Level]  # value = <Level.Critical: 5>
        Debug: typing.ClassVar[Logger.Level]  # value = <Level.Debug: 1>
        Error: typing.ClassVar[Logger.Level]  # value = <Level.Error: 4>
        Info: typing.ClassVar[Logger.Level]  # value = <Level.Info: 2>
        Trace: typing.ClassVar[Logger.Level]  # value = <Level.Trace: 0>
        Warn: typing.ClassVar[Logger.Level]  # value = <Level.Warn: 3>
        __members__: typing.ClassVar[dict[str, Logger.Level]]  # value = {'Trace': <Level.Trace: 0>, 'Debug': <Level.Debug: 1>, 'Info': <Level.Info: 2>, 'Warn': <Level.Warn: 3>, 'Error': <Level.Error: 4>, 'Critical': <Level.Critical: 5>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    Critical: typing.ClassVar[Logger.Level]  # value = <Level.Critical: 5>
    Debug: typing.ClassVar[Logger.Level]  # value = <Level.Debug: 1>
    Error: typing.ClassVar[Logger.Level]  # value = <Level.Error: 4>
    Info: typing.ClassVar[Logger.Level]  # value = <Level.Info: 2>
    Trace: typing.ClassVar[Logger.Level]  # value = <Level.Trace: 0>
    Warn: typing.ClassVar[Logger.Level]  # value = <Level.Warn: 3>
    @staticmethod
    def critical(msg: str) -> None:
        """
        Log a critical message.
        Args:
            msg: Message to log.
        """
    @staticmethod
    def debug(msg: str) -> None:
        """
        Log a debug message.
        Args:
            msg: Message to log.
        """
    @staticmethod
    def error(msg: str) -> None:
        """
        Log an error message.
        Args:
            msg: Message to log.
        """
    @staticmethod
    def info(msg: str) -> None:
        """
        Log an info message.
        Args:
            msg: Message to log.
        """
    @staticmethod
    def log(level: Logger.Level, msg: str) -> None:
        """
        Log a message at the specified level.
        Args:
            level: Logging level.
            msg: Message to log.
        """
    @staticmethod
    def set_level(level: Logger.Level) -> None:
        """
        Set the logging level.
        Args:
            level: Logging level (Trace, Debug, Info, Warn, Error, Critical).
        """
    @staticmethod
    def set_pattern(pattern: str) -> None:
        """
        Set the logging pattern format.
        Args:
            pattern: Format pattern string for log messages.
        """
    @staticmethod
    def warn(msg: str) -> None:
        """
        Log a warning message.
        Args:
            msg: Message to log.
        """
class Matrix12x12:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
class Matrix2x2:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
class Matrix3x3:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
class Matrix4x4:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
class Matrix6x6:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
class Matrix9x9:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
class Quaternion:
    """
    Quaternion class for representing 3D rotations.
    """
    @staticmethod
    def Identity() -> Quaternion:
        """
        Create an identity quaternion (no rotation).
        Returns:
            Quaternion: Identity quaternion.
        """
    @typing.overload
    def __init__(self, wxyz: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Create a quaternion from w, x, y, z components.
        Args:
            wxyz: Array of 4 floats [w, x, y, z] representing the quaternion.
        """
    @typing.overload
    def __init__(self, angle_axis: AngleAxis) -> None:
        """
        Create a quaternion from an AngleAxis.
        Args:
            angle_axis: AngleAxis object to convert.
        """
    @typing.overload
    def __mul__(self, other: Quaternion) -> Quaternion:
        """
        Multiply two quaternions (composition of rotations).
        Args:
            other: Another quaternion.
        Returns:
            Quaternion: Result of quaternion multiplication.
        """
    @typing.overload
    def __mul__(self, angle_axis: AngleAxis) -> Quaternion:
        """
        Multiply quaternion by angle-axis.
        Args:
            angle_axis: AngleAxis to multiply with.
        Returns:
            Quaternion: Result of multiplication.
        """
    def conjugate(self) -> Quaternion:
        """
        Get the conjugate quaternion.
        Returns:
            Quaternion: Conjugate quaternion.
        """
    def inverse(self) -> Quaternion:
        """
        Get the inverse quaternion.
        Returns:
            Quaternion: Inverse quaternion.
        """
    def norm(self) -> float:
        """
        Get the norm (magnitude) of the quaternion.
        Returns:
            float: Norm of the quaternion.
        """
    def normalized(self) -> Quaternion:
        """
        Get a normalized copy of the quaternion.
        Returns:
            Quaternion: Normalized quaternion.
        """
class ResidentThread:
    """
    Resident thread for executing Python callables in a separate thread.
    """
    def __init__(self) -> None:
        """
        Create a new resident thread.
        """
    def is_ready(self) -> bool:
        """
        Check if the resident thread is ready to accept new tasks.
        Returns:
            bool: True if the thread is ready, False otherwise.
        """
    def post(self, func: collections.abc.Callable) -> bool:
        """
        Post a callable to be executed in the resident thread.
        Args:
            func: Python callable object (function) with no arguments to execute.
        Returns:
            bool: True if the function was successfully posted.
        """
class SizeT:
    """
    Type wrapper for scalar values.
    """
    @staticmethod
    def One() -> int:
        """
        Get one value.
        Returns:
            Scalar: One value.
        """
    @staticmethod
    def Value(value: typing.SupportsInt | typing.SupportsIndex) -> int:
        """
        Create a scalar value.
        Args:
            value: Scalar value.
        Returns:
            Scalar: The value.
        """
    @staticmethod
    def Zero() -> int:
        """
        Get zero value.
        Returns:
            Scalar: Zero value.
        """
    @staticmethod
    def size_bytes() -> int:
        """
        Get the size in bytes.
        Returns:
            int: Size in bytes.
        """
class Timer:
    """
    Timer class for performance profiling and timing measurements.
    """
    @staticmethod
    def disable_all() -> None:
        """
        Disable all timers.
        """
    @staticmethod
    def enable_all() -> None:
        """
        Enable all timers for performance measurement.
        """
    @staticmethod
    def report() -> None:
        """
        Print timing report to the console.
        """
    @staticmethod
    def report_as_json() -> json:
        """
        Get timing report as a JSON object.
        Returns:
            dict: Timing report as a dictionary.
        """
class Transform:
    """
    Transform class representing a 4x4 homogeneous transformation matrix.
    """
    @staticmethod
    def Identity() -> Transform:
        """
        Create an identity transform (no translation, no rotation, unit scale).
        Returns:
            Transform: Identity transformation matrix.
        """
    def __init__(self, matrix: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> None:
        """
        Create a transform from a 4x4 matrix.
        Args:
            matrix: 4x4 transformation matrix.
        """
    @typing.overload
    def __mul__(self, other: Transform) -> Transform:
        """
        Compose two transforms (matrix multiplication).
        Args:
            other: Another transform.
        Returns:
            Transform: Result of transform composition.
        """
    @typing.overload
    def __mul__(self, vector: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Apply transform to a 3D vector.
        Args:
            vector: 3D vector to transform.
        Returns:
            numpy.ndarray: Transformed 3D vector.
        """
    def apply_to(self, vectors: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Apply transform to a vector or array of vectors (in-place for arrays).
        Args:
            vectors: Single 3D vector or array of 3D vectors.
        Returns:
            numpy.ndarray: Transformed vector(s).
        """
    def inverse(self) -> Transform:
        """
        Get the inverse transform.
        Returns:
            Transform: Inverse transformation matrix.
        """
    def matrix(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get the 4x4 transformation matrix.
        Returns:
            numpy.ndarray: 4x4 transformation matrix.
        """
    @typing.overload
    def prerotate(self, angle_axis: AngleAxis) -> Transform:
        """
        Apply rotation to the transform (pre-multiply).
        Args:
            angle_axis: AngleAxis rotation.
        Returns:
            Transform: Reference to self for chaining.
        """
    @typing.overload
    def prerotate(self, quaternion: Quaternion) -> Transform:
        """
        Apply rotation to the transform (pre-multiply).
        Args:
            quaternion: Quaternion rotation.
        Returns:
            Transform: Reference to self for chaining.
        """
    def prescale(self, scale: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> Transform:
        """
        Apply scaling to the transform (pre-multiply).
        Args:
            scale: Either a scalar (uniform scale) or 3D vector (non-uniform scale).
        Returns:
            Transform: Reference to self for chaining.
        """
    def pretranslate(self, translation: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> Transform:
        """
        Apply translation to the transform (pre-multiply).
        Args:
            translation: 3D translation vector.
        Returns:
            Transform: Reference to self for chaining.
        """
    @typing.overload
    def rotate(self, angle_axis: AngleAxis) -> Transform:
        """
        Apply rotation to the transform (post-multiply).
        Args:
            angle_axis: AngleAxis rotation.
        Returns:
            Transform: Reference to self for chaining.
        """
    @typing.overload
    def rotate(self, quaternion: Quaternion) -> Transform:
        """
        Apply rotation to the transform (post-multiply).
        Args:
            quaternion: Quaternion rotation.
        Returns:
            Transform: Reference to self for chaining.
        """
    def scale(self, scale: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> Transform:
        """
        Apply scaling to the transform (post-multiply).
        Args:
            scale: Either a scalar (uniform scale) or 3D vector (non-uniform scale).
        Returns:
            Transform: Reference to self for chaining.
        """
    def translate(self, translation: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> Transform:
        """
        Apply translation to the transform (post-multiply).
        Args:
            translation: 3D translation vector.
        Returns:
            Transform: Reference to self for chaining.
        """
    def translation(self) -> numpy.typing.NDArray[numpy.float64]:
        """
        Get the translation component of the transform.
        Returns:
            numpy.ndarray: 3D translation vector.
        """
class U32:
    """
    Type wrapper for scalar values.
    """
    @staticmethod
    def One() -> int:
        """
        Get one value.
        Returns:
            Scalar: One value.
        """
    @staticmethod
    def Value(value: typing.SupportsInt | typing.SupportsIndex) -> int:
        """
        Create a scalar value.
        Args:
            value: Scalar value.
        Returns:
            Scalar: The value.
        """
    @staticmethod
    def Zero() -> int:
        """
        Get zero value.
        Returns:
            Scalar: Zero value.
        """
    @staticmethod
    def size_bytes() -> int:
        """
        Get the size in bytes.
        Returns:
            int: Size in bytes.
        """
class U64:
    """
    Type wrapper for scalar values.
    """
    @staticmethod
    def One() -> int:
        """
        Get one value.
        Returns:
            Scalar: One value.
        """
    @staticmethod
    def Value(value: typing.SupportsInt | typing.SupportsIndex) -> int:
        """
        Create a scalar value.
        Args:
            value: Scalar value.
        Returns:
            Scalar: The value.
        """
    @staticmethod
    def Zero() -> int:
        """
        Get zero value.
        Returns:
            Scalar: Zero value.
        """
    @staticmethod
    def size_bytes() -> int:
        """
        Get the size in bytes.
        Returns:
            int: Size in bytes.
        """
class Vector12:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, n: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector.
        Args:
            start: Start value.
            end: End value.
            n: Number of points.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector (size M).
        Args:
            start: Start value.
            end: End value.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, step: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector with step size.
        Args:
            start: Start value.
            end: End value.
            step: Step size.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Unit(i: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector with 1 at index i.
        Args:
            i: Index of the unit element (0-based).
        Returns:
            numpy.ndarray: Unit vector.
        """
    @staticmethod
    def UnitW() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in W direction.
        Returns:
            numpy.ndarray: Unit W vector.
        """
    @staticmethod
    def UnitX() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in X direction.
        Returns:
            numpy.ndarray: Unit X vector.
        """
    @staticmethod
    def UnitY() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in Y direction.
        Returns:
            numpy.ndarray: Unit Y vector.
        """
    @staticmethod
    def UnitZ() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in Z direction.
        Returns:
            numpy.ndarray: Unit Z vector.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
class Vector2:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, n: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector.
        Args:
            start: Start value.
            end: End value.
            n: Number of points.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector (size M).
        Args:
            start: Start value.
            end: End value.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, step: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector with step size.
        Args:
            start: Start value.
            end: End value.
            step: Step size.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Unit(i: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector with 1 at index i.
        Args:
            i: Index of the unit element (0-based).
        Returns:
            numpy.ndarray: Unit vector.
        """
    @staticmethod
    def UnitX() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in X direction.
        Returns:
            numpy.ndarray: Unit X vector.
        """
    @staticmethod
    def UnitY() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in Y direction.
        Returns:
            numpy.ndarray: Unit Y vector.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
class Vector3:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, n: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector.
        Args:
            start: Start value.
            end: End value.
            n: Number of points.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector (size M).
        Args:
            start: Start value.
            end: End value.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, step: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector with step size.
        Args:
            start: Start value.
            end: End value.
            step: Step size.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Unit(i: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector with 1 at index i.
        Args:
            i: Index of the unit element (0-based).
        Returns:
            numpy.ndarray: Unit vector.
        """
    @staticmethod
    def UnitX() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in X direction.
        Returns:
            numpy.ndarray: Unit X vector.
        """
    @staticmethod
    def UnitY() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in Y direction.
        Returns:
            numpy.ndarray: Unit Y vector.
        """
    @staticmethod
    def UnitZ() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in Z direction.
        Returns:
            numpy.ndarray: Unit Z vector.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
class Vector4:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, n: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector.
        Args:
            start: Start value.
            end: End value.
            n: Number of points.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector (size M).
        Args:
            start: Start value.
            end: End value.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, step: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector with step size.
        Args:
            start: Start value.
            end: End value.
            step: Step size.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Unit(i: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector with 1 at index i.
        Args:
            i: Index of the unit element (0-based).
        Returns:
            numpy.ndarray: Unit vector.
        """
    @staticmethod
    def UnitW() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in W direction.
        Returns:
            numpy.ndarray: Unit W vector.
        """
    @staticmethod
    def UnitX() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in X direction.
        Returns:
            numpy.ndarray: Unit X vector.
        """
    @staticmethod
    def UnitY() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in Y direction.
        Returns:
            numpy.ndarray: Unit Y vector.
        """
    @staticmethod
    def UnitZ() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in Z direction.
        Returns:
            numpy.ndarray: Unit Z vector.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
class Vector6:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, n: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector.
        Args:
            start: Start value.
            end: End value.
            n: Number of points.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector (size M).
        Args:
            start: Start value.
            end: End value.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, step: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector with step size.
        Args:
            start: Start value.
            end: End value.
            step: Step size.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Unit(i: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector with 1 at index i.
        Args:
            i: Index of the unit element (0-based).
        Returns:
            numpy.ndarray: Unit vector.
        """
    @staticmethod
    def UnitW() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in W direction.
        Returns:
            numpy.ndarray: Unit W vector.
        """
    @staticmethod
    def UnitX() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in X direction.
        Returns:
            numpy.ndarray: Unit X vector.
        """
    @staticmethod
    def UnitY() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in Y direction.
        Returns:
            numpy.ndarray: Unit Y vector.
        """
    @staticmethod
    def UnitZ() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in Z direction.
        Returns:
            numpy.ndarray: Unit Z vector.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
class Vector9:
    """
    Type wrapper for matrix values.
    """
    @staticmethod
    def Identity() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create an identity matrix (only for square matrices).
        Returns:
            numpy.ndarray: Identity matrix.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, n: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector.
        Args:
            start: Start value.
            end: End value.
            n: Number of points.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector (size M).
        Args:
            start: Start value.
            end: End value.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    @typing.overload
    def LinSpaced(start: typing.SupportsFloat | typing.SupportsIndex, end: typing.SupportsFloat | typing.SupportsIndex, step: typing.SupportsFloat | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a linearly spaced vector with step size.
        Args:
            start: Start value.
            end: End value.
            step: Step size.
        Returns:
            numpy.ndarray: Linearly spaced vector.
        """
    @staticmethod
    def Ones() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix of ones.
        Returns:
            numpy.ndarray: Matrix filled with ones.
        """
    @staticmethod
    def Random() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a random matrix.
        Returns:
            numpy.ndarray: Random matrix.
        """
    @staticmethod
    def Unit(i: typing.SupportsInt | typing.SupportsIndex) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector with 1 at index i.
        Args:
            i: Index of the unit element (0-based).
        Returns:
            numpy.ndarray: Unit vector.
        """
    @staticmethod
    def UnitW() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in W direction.
        Returns:
            numpy.ndarray: Unit W vector.
        """
    @staticmethod
    def UnitX() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in X direction.
        Returns:
            numpy.ndarray: Unit X vector.
        """
    @staticmethod
    def UnitY() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in Y direction.
        Returns:
            numpy.ndarray: Unit Y vector.
        """
    @staticmethod
    def UnitZ() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a unit vector in Z direction.
        Returns:
            numpy.ndarray: Unit Z vector.
        """
    @staticmethod
    def Values(value: typing.Annotated[numpy.typing.ArrayLike, numpy.float64]) -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a matrix from a numpy array.
        Args:
            value: Numpy array to convert.
        Returns:
            numpy.ndarray: Matrix.
        """
    @staticmethod
    def Zero() -> numpy.typing.NDArray[numpy.float64]:
        """
        Create a zero matrix.
        Returns:
            numpy.ndarray: Zero matrix.
        """
    @staticmethod
    def shape() -> tuple[int, int]:
        """
        Get the matrix shape.
        Returns:
            tuple: (rows, cols) shape tuple.
        """
def config() -> json:
    """
    Get the current configuration of libuipc.
    Returns:
        dict: Current configuration dictionary.
    """
def default_config() -> json:
    """
    Get the default configuration for libuipc.
    Returns:
        dict: Default configuration dictionary.
    """
def init(dict: json) -> None:
    """
    Initialize the libuipc library with the given configuration.
    Args:
        dict: Configuration dictionary containing library settings.
    """
@typing.overload
def view(slot: geometry.AttributeSlotString) -> geometry.StringSpan:
    """
    Get a view of a string attribute slot.
    Args:
        slot: AttributeSlotString to view.
    Returns:
        StringSpan: View of string attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotFloat) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotI32) -> numpy.typing.NDArray[numpy.int32]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotI64) -> numpy.typing.NDArray[numpy.int64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotU32) -> numpy.typing.NDArray[numpy.uint32]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotU64) -> numpy.typing.NDArray[numpy.uint64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotVector2) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotVector3) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotVector4) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotVector6) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotVector9) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotVector12) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotVector2i) -> numpy.typing.NDArray[numpy.int32]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotVector3i) -> numpy.typing.NDArray[numpy.int32]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotVector4i) -> numpy.typing.NDArray[numpy.int32]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotMatrix2x2) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotMatrix3x3) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotMatrix4x4) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotMatrix6x6) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotMatrix9x9) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(slot: geometry.AttributeSlotMatrix12x12) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a numpy array view of an attribute slot.
    Args:
        slot: AttributeSlot to view.
    Returns:
        numpy.ndarray: Array view of attribute data.
    """
@typing.overload
def view(pc: diff_sim.ParameterCollection) -> numpy.typing.NDArray[numpy.float64]:
    """
    Get a view of parameter collection as a numpy array.
    Args:
        pc: ParameterCollection to view.
    Returns:
        numpy.ndarray: Array view of parameters.
    """
__version__: str = '0.9.0'
