from __future__ import annotations
import collections.abc
import numpy
import numpy.typing
import typing
import uipc._native.pyuipc.backend
import uipc._native.pyuipc.constitution
import uipc._native.pyuipc.diff_sim
import uipc._native.pyuipc.geometry
__all__: list[str] = ['AffineBodyStateAccessorFeature', 'Animation', 'Animator', 'ConstitutionTabular', 'ContactElement', 'ContactModel', 'ContactModelCollection', 'ContactSystemFeature', 'ContactTabular', 'DiffSim', 'DistanceDiagnoserFeature', 'Engine', 'EngineStatus', 'EngineStatusCollection', 'Error', 'Feature', 'FeatureCollection', 'FiniteElementStateAccessorFeature', 'IEngine', 'Object', 'PyIEngine', 'SanityCheckMessage', 'SanityCheckResult', 'SanityChecker', 'Scene', 'SceneFactory', 'SceneIO', 'SceneSnapshot', 'SceneSnapshotCommit', 'SubsceneElement', 'SubsceneModel', 'SubsceneModelCollection', 'SubsceneTabular', 'Success', 'Warning', 'World']
class AffineBodyStateAccessorFeature(Feature):
    """
    Feature for accessing affine body simulation state (body transforms, velocities, etc.).
    """
    FeatureName: typing.ClassVar[str] = 'core/affine_body_state_accessor'
    def body_count(self) -> int:
        """
        Get the number of affine bodies.
        Returns:
            int: Number of affine bodies.
        """
    def copy_from(self, state_geo: uipc._native.pyuipc.geometry.SimplicialComplex) -> None:
        """
        Copy state from geometry.
        Args:
            state_geo: Geometry containing state data to copy from.
        """
    def copy_to(self, state_geo: uipc._native.pyuipc.geometry.SimplicialComplex) -> None:
        """
        Copy state to geometry.
        Args:
            state_geo: Geometry to copy state data to.
        """
    def copy_transform_to(self, buffer_view: uipc._native.pyuipc.backend.BufferView, body_offset: typing.SupportsInt | typing.SupportsIndex = 0, body_count: typing.SupportsInt | typing.SupportsIndex = 18446744073709551615) -> None:
        """
        Copy transform data (Matrix4x4) for the specified body range into an externally-owned buffer.
        Args:
            buffer_view: Destination buffer view to copy transform data into.
            body_offset: Starting body index (default: 0).
            body_count: Number of bodies to include (default: all).
        """
    def copy_velocity_to(self, buffer_view: uipc._native.pyuipc.backend.BufferView, body_offset: typing.SupportsInt | typing.SupportsIndex = 0, body_count: typing.SupportsInt | typing.SupportsIndex = 18446744073709551615) -> None:
        """
        Copy velocity data (Matrix4x4) for the specified body range into an externally-owned buffer.
        Args:
            buffer_view: Destination buffer view to copy velocity data into.
            body_offset: Starting body index (default: 0).
            body_count: Number of bodies to include (default: all).
        """
    def create_geometry(self, body_offset: typing.SupportsInt | typing.SupportsIndex = 0, body_count: typing.SupportsInt | typing.SupportsIndex = 18446744073709551615) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create geometry from state data.
        Args:
            body_offset: Starting body index (default: 0).
            body_count: Number of bodies to include (default: all).
        Returns:
            Geometry: Geometry created from state data.
        """
class Animation:
    """
    Animation class for managing object animations.
    """
    class UpdateHint:
        """
        Update hint enumeration for animation updates.
        """
    class UpdateInfo:
        """
        Update information passed to animation callbacks.
        """
        def dt(self) -> float:
            """
            Get the time step.
            Returns:
                float: Time step (delta time).
            """
        def frame(self) -> int:
            """
            Get the current frame number.
            Returns:
                int: Current frame number.
            """
        def geo_slots(self) -> list:
            """
            Get the geometry slots.
            Returns:
                list: List of geometry slots.
            """
        def hint(self) -> Animation.UpdateHint:
            """
            Get the update hint.
            Returns:
                UpdateHint: Update hint value.
            """
        def object(self) -> Object:
            """
            Get the object being animated.
            Returns:
                Object: Reference to the object.
            """
        def rest_geo_slots(self) -> list:
            """
            Get the rest geometry slots.
            Returns:
                list: List of rest geometry slots.
            """
class Animator:
    """
    Animator class for managing object animations in a scene.
    """
    def __repr__(self) -> str:
        """
        String representation of the animator.
        Returns:
            str: Formatted animator summary.
        """
    def animation_count(self) -> int:
        """
        Get the number of animated objects.
        Returns:
            int: Number of objects that currently have animation callbacks.
        """
    def animation_ids(self) -> list[int]:
        """
        Get sorted object ids that have registered animation callbacks.
        Returns:
            list[int]: Animated object ids.
        """
    def erase(self, object: typing.SupportsInt | typing.SupportsIndex) -> None:
        """
        Remove animation callback for an object.
        Args:
            object: Object to remove animation from.
        """
    def has_animation(self, object_id: typing.SupportsInt | typing.SupportsIndex) -> bool:
        """
        Check whether an object has a registered animation callback.
        Args:
            object_id: Object id to query.
        Returns:
            bool: True if the object is animated, False otherwise.
        """
    def insert(self, object: Object, callable: collections.abc.Callable) -> None:
        """
        Insert an animation callback for an object.
        Args:
            object: Object to animate.
            callable: Python function that takes an UpdateInfo argument and updates the object.
        """
    @typing.overload
    def substep(self, substep: typing.SupportsInt | typing.SupportsIndex) -> None:
        """
        Set the substep count.
        Args:
            substep: Number of substeps per frame.
        """
    @typing.overload
    def substep(self) -> int:
        """
        Get the substep count.
        Returns:
            int: Number of substeps per frame.
        """
class ConstitutionTabular:
    """
    ConstitutionTabular class managing constitutions (material models) in a scene.
    """
    def __init__(self) -> None:
        """
        Create an empty constitution tabular.
        """
    def insert(self, constitution: uipc._native.pyuipc.constitution.IConstitution) -> None:
        """
        Insert a constitution into the tabular.
        Args:
            constitution: Constitution to insert.
        """
    def types(self) -> set[str]:
        """
        Get the types of all constitutions.
        Returns:
            list: List of constitution type names.
        """
    def uids(self) -> numpy.typing.NDArray[numpy.uint64]:
        """
        Get the UIDs of all constitutions.
        Returns:
            numpy.ndarray: Array of constitution UIDs.
        """
class ContactElement:
    """
    ContactElement class representing a contact element (object or geometry).
    """
    def __init__(self, id: typing.SupportsInt | typing.SupportsIndex, name: str) -> None:
        """
        Create a contact element.
        Args:
            id: Element ID.
            name: Element name.
        """
    def apply_to(self, object: uipc._native.pyuipc.geometry.Geometry) -> uipc._native.pyuipc.geometry.AttributeSlotI32:
        """
        Apply this contact element to an object.
        Args:
            object: Object to apply to.
        """
    def id(self) -> int:
        """
        Get the element ID.
        Returns:
            int: Element ID.
        """
    def name(self) -> str:
        """
        Get the element name.
        Returns:
            str: Element name.
        """
class ContactModel:
    """
    ContactModel class representing contact parameters between two elements.
    """
    def config(self) -> json:
        """
        Get the configuration dictionary.
        Returns:
            dict: Configuration dictionary.
        """
    def friction_rate(self) -> float:
        """
        Get the friction rate.
        Returns:
            float: Friction rate value.
        """
    def is_enabled(self) -> bool:
        """
        Check if the contact model is enabled.
        Returns:
            bool: True if enabled, False otherwise.
        """
    def resistance(self) -> float:
        """
        Get the resistance value.
        Returns:
            float: Resistance value.
        """
    def topo(self) -> numpy.typing.NDArray[numpy.int32]:
        """
        Get the topology IDs.
        Returns:
            numpy.ndarray: Array of two integers representing the topology IDs.
        """
class ContactModelCollection:
    """
    Collection of contact models with attributes.
    """
    def __repr__(self) -> str:
        """
        String representation of the collection.
        Returns:
            str: Formatted JSON string.
        """
    def create(self, name: str, default_value: typing.Any) -> uipc._native.pyuipc.geometry.IAttributeSlot:
        """
        Create a contact model attribute.
        Args:
            name: Attribute name.
            default_value: Default value for the attribute.
        Returns:
            AttributeSlot: Created attribute slot.
        """
    def find(self, name: str) -> uipc._native.pyuipc.geometry.IAttributeSlot:
        """
        Find a contact model attribute by name.
        Args:
            name: Attribute name.
        Returns:
            AttributeSlot or None: Attribute slot if found, None otherwise.
        """
class ContactSystemFeature(Feature):
    """
    Feature for computing contact energy, gradients, and Hessians.
    """
    FeatureName: typing.ClassVar[str] = 'core/contact_system'
    @typing.overload
    def contact_energy(self, prim_type: str, energy: uipc._native.pyuipc.geometry.Geometry) -> None:
        """
        Compute contact energy for a primitive type.
        Args:
            prim_type: Primitive type string.
            energy: Geometry to store energy values (modified in-place).
        """
    @typing.overload
    def contact_energy(self, constitution: uipc._native.pyuipc.constitution.IConstitution, prims: uipc._native.pyuipc.geometry.Geometry) -> None:
        """
        Compute contact energy for a constitution.
        Args:
            constitution: Constitution to compute energy for.
            prims: Geometry containing primitives (modified in-place with energy values).
        """
    @typing.overload
    def contact_gradient(self, prim_type: str, vert_grad: uipc._native.pyuipc.geometry.Geometry) -> None:
        """
        Compute contact gradient for a primitive type.
        Args:
            prim_type: Primitive type string.
            vert_grad: Geometry to store vertex gradients (modified in-place).
        """
    @typing.overload
    def contact_gradient(self, constitution: uipc._native.pyuipc.constitution.IConstitution, vert_grad: uipc._native.pyuipc.geometry.Geometry) -> None:
        """
        Compute contact gradient for a constitution.
        Args:
            constitution: Constitution to compute gradient for.
            vert_grad: Geometry to store vertex gradients (modified in-place).
        """
    @typing.overload
    def contact_hessian(self, prim_type: str, vert_hess: uipc._native.pyuipc.geometry.Geometry) -> None:
        """
        Compute contact Hessian for a primitive type.
        Args:
            prim_type: Primitive type string.
            vert_hess: Geometry to store vertex Hessians (modified in-place).
        """
    @typing.overload
    def contact_hessian(self, constitution: uipc._native.pyuipc.constitution.IConstitution, vert_hess: uipc._native.pyuipc.geometry.Geometry) -> None:
        """
        Compute contact Hessian for a constitution.
        Args:
            constitution: Constitution to compute Hessian for.
            vert_hess: Geometry to store vertex Hessians (modified in-place).
        """
    def contact_primitive_types(self) -> list[str]:
        """
        Get the list of supported primitive types.
        Returns:
            list: List of primitive type strings.
        """
class ContactTabular:
    """
    ContactTabular class managing contact elements and contact models between them.
    """
    def at(self, i: typing.SupportsInt | typing.SupportsIndex, j: typing.SupportsInt | typing.SupportsIndex) -> ContactModel:
        """
        Get the contact model between two elements.
        Args:
            i: First element ID.
            j: Second element ID.
        Returns:
            ContactModel: Contact model between the two elements.
        """
    def contact_models(self) -> ContactModelCollection:
        """
        Get the contact model collection.
        Returns:
            ContactModelCollection: Collection of contact models.
        """
    def create(self, name: str = '') -> ContactElement:
        """
        Create a new contact element.
        Args:
            name: Element name (optional).
        Returns:
            ContactElement: Created contact element.
        """
    def default_element(self) -> ContactElement:
        """
        Get the default contact element.
        Returns:
            ContactElement: Reference to default element.
        """
    @typing.overload
    def default_model(self, friction_rate: typing.SupportsFloat | typing.SupportsIndex, resistance: typing.SupportsFloat | typing.SupportsIndex, enable: bool = True, config: json = {}) -> None:
        """
        Set the default contact model parameters.
        Args:
            friction_rate: Default friction rate.
            resistance: Default resistance value.
            enable: Whether contacts are enabled by default (default: True).
            config: Default configuration dictionary (default: empty).
        """
    @typing.overload
    def default_model(self) -> ContactModel:
        """
        Get the default contact model.
        Returns:
            ContactModel: Default contact model.
        """
    def element_count(self) -> int:
        """
        Get the number of contact elements.
        Returns:
            int: Number of elements.
        """
    def insert(self, L: ContactElement, R: ContactElement, friction_rate: typing.SupportsFloat | typing.SupportsIndex, resistance: typing.SupportsFloat | typing.SupportsIndex, enable: bool = True, config: json = {}) -> int:
        """
        Insert a contact model between two elements.
        Args:
            L: Left element ID.
            R: Right element ID.
            friction_rate: Friction rate value.
            resistance: Resistance value.
            enable: Whether the contact is enabled (default: True).
            config: Additional configuration dictionary (default: empty).
        """
class DiffSim:
    """
    DiffSim class for differential simulation parameters and state.
    """
    def parameters(self) -> uipc._native.pyuipc.diff_sim.ParameterCollection:
        """
        Get the parameter collection.
        Returns:
            Reference to the parameter collection.
        """
class DistanceDiagnoserFeature(Feature):
    FeatureName: typing.ClassVar[str] = 'core/distance_diagnoser'
    def compute_edge_edge_distance(self, R: uipc._native.pyuipc.geometry.Geometry, edges_a: uipc._native.pyuipc.geometry.SimplicialComplex, edges_b: uipc._native.pyuipc.geometry.SimplicialComplex, rest_edges_a: uipc._native.pyuipc.geometry.SimplicialComplex, rest_edges_b: uipc._native.pyuipc.geometry.SimplicialComplex) -> None:
        ...
    def compute_point_edge_distance(self, R: uipc._native.pyuipc.geometry.Geometry, points: uipc._native.pyuipc.geometry.SimplicialComplex, edges: uipc._native.pyuipc.geometry.SimplicialComplex) -> None:
        ...
    def compute_point_point_distance(self, R: uipc._native.pyuipc.geometry.Geometry, points_a: uipc._native.pyuipc.geometry.SimplicialComplex, points_b: uipc._native.pyuipc.geometry.SimplicialComplex) -> None:
        ...
    def compute_point_triangle_distance(self, R: uipc._native.pyuipc.geometry.Geometry, points: uipc._native.pyuipc.geometry.SimplicialComplex, triangles: uipc._native.pyuipc.geometry.SimplicialComplex) -> None:
        ...
class Engine:
    """
    Engine class for running simulations with a specific backend.
    """
    @staticmethod
    def default_config() -> json:
        """
        Get the default engine configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    @typing.overload
    def __init__(self, backend_name: str, workspace: str = './', config: json = {'extras': {'gui': {'enable': True}}, 'gpu': {'device': 0}}) -> None:
        """
        Create an engine with a backend.
        Args:
            backend_name: Name of the backend to use (e.g., 'cuda', 'none').
            workspace: Workspace directory path (default: './').
            config: Configuration dictionary (optional, uses default if not provided).
        """
    @typing.overload
    def __init__(self, backend_name: str, overrider: IEngine, workspace: str = './', config: json = {'extras': {'gui': {'enable': True}}, 'gpu': {'device': 0}}) -> None:
        """
        Create an engine with a custom engine overrider.
        Args:
            backend_name: Name of the backend to use.
            overrider: Custom IEngine implementation.
            workspace: Workspace directory path (default: './').
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def backend_name(self) -> str:
        """
        Get the backend name.
        Returns:
            str: Backend name.
        """
    def features(self) -> FeatureCollection:
        """
        Get the feature collection.
        Returns:
            FeatureCollection: Reference to feature collection.
        """
    def workspace(self) -> str:
        """
        Get the workspace directory.
        Returns:
            str: Workspace directory path.
        """
class EngineStatus:
    """
    Engine status message indicating info, warning, or error.
    """
    class Type:
        """
        Engine status type enumeration.
        
        Members:
        
          None
        
          Info
        
          Warning
        
          Error
        """
        Error: typing.ClassVar[EngineStatus.Type]  # value = <Type.Error: 3>
        Info: typing.ClassVar[EngineStatus.Type]  # value = <Type.Info: 1>
        None: typing.ClassVar[EngineStatus.Type]  # value = <Type.None: 0>
        Warning: typing.ClassVar[EngineStatus.Type]  # value = <Type.Warning: 2>
        __members__: typing.ClassVar[dict[str, EngineStatus.Type]]  # value = {'None': <Type.None: 0>, 'Info': <Type.Info: 1>, 'Warning': <Type.Warning: 2>, 'Error': <Type.Error: 3>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    Error: typing.ClassVar[EngineStatus.Type]  # value = <Type.Error: 3>
    Info: typing.ClassVar[EngineStatus.Type]  # value = <Type.Info: 1>
    None: typing.ClassVar[EngineStatus.Type]  # value = <Type.None: 0>
    Warning: typing.ClassVar[EngineStatus.Type]  # value = <Type.Warning: 2>
    @staticmethod
    def error(msg: str) -> EngineStatus:
        """
        Create an error status.
        Args:
            msg: Error message.
        Returns:
            EngineStatus: Error status object.
        """
    @staticmethod
    def info(msg: str) -> EngineStatus:
        """
        Create an info status.
        Args:
            msg: Info message.
        Returns:
            EngineStatus: Info status object.
        """
    @staticmethod
    def warning(msg: str) -> EngineStatus:
        """
        Create a warning status.
        Args:
            msg: Warning message.
        Returns:
            EngineStatus: Warning status object.
        """
    def type(self) -> EngineStatus.Type:
        """
        Get the status type.
        Returns:
            Status type enumeration (None, Info, Warning, or Error).
        """
    def what(self) -> str:
        """
        Get the status message.
        Returns:
            str: Status message string.
        """
class EngineStatusCollection:
    """
    Collection of engine status messages.
    """
    def __init__(self) -> None:
        """
        Create an empty status collection.
        """
    def has_error(self) -> bool:
        """
        Check if the collection contains any errors.
        Returns:
            bool: True if any error status exists, False otherwise.
        """
    def push_back(self, status: EngineStatus) -> None:
        """
        Add a status to the collection.
        Args:
            status: EngineStatus to add.
        """
    def to_json(self) -> json:
        """
        Convert status collection to JSON.
        Returns:
            dict: JSON representation of the status collection.
        """
class Feature:
    """
    Feature interface for extensible engine functionality.
    """
    def name(self) -> str:
        """
        Get the feature name.
        Returns:
            str: Feature name.
        """
    def type_name(self) -> str:
        """
        Get the feature type name.
        Returns:
            str: Feature type name.
        """
class FeatureCollection:
    """
    FeatureCollection class managing engine features.
    """
    def __repr__(self) -> str:
        """
        String representation of the feature collection.
        Returns:
            str: Formatted JSON string.
        """
    @typing.overload
    def find(self, name: str) -> Feature:
        """
        Find a feature by name.
        Args:
            name: Feature name.
        Returns:
            Feature or None: Feature if found, None otherwise.
        """
    @typing.overload
    def find(self, type: type) -> Feature:
        """
        Find a feature by type.
        Args:
            type: Feature type (must have FeatureName attribute).
        Returns:
            Feature or None: Feature if found, None otherwise.
        """
    def to_json(self) -> json:
        """
        Convert feature collection to JSON.
        Returns:
            dict: JSON representation of the feature collection.
        """
class FiniteElementStateAccessorFeature(Feature):
    """
    Feature for accessing finite element simulation state (vertex positions, velocities, etc.).
    """
    FeatureName: typing.ClassVar[str] = 'core/finite_element_state_accessor'
    def copy_from(self, state_geo: uipc._native.pyuipc.geometry.SimplicialComplex) -> None:
        """
        Copy state from geometry.
        Args:
            state_geo: Geometry containing state data to copy from.
        """
    def copy_position_to(self, buffer_view: uipc._native.pyuipc.backend.BufferView, vertex_offset: typing.SupportsInt | typing.SupportsIndex = 0, vertex_count: typing.SupportsInt | typing.SupportsIndex = 18446744073709551615) -> None:
        """
        Copy position data (Vector3) for the specified vertex range into an externally-owned buffer.
        Args:
            buffer_view: Destination buffer view to copy position data into.
            vertex_offset: Starting vertex index (default: 0).
            vertex_count: Number of vertices to include (default: all).
        """
    def copy_to(self, state_geo: uipc._native.pyuipc.geometry.SimplicialComplex) -> None:
        """
        Copy state to geometry.
        Args:
            state_geo: Geometry to copy state data to.
        """
    def copy_velocity_to(self, buffer_view: uipc._native.pyuipc.backend.BufferView, vertex_offset: typing.SupportsInt | typing.SupportsIndex = 0, vertex_count: typing.SupportsInt | typing.SupportsIndex = 18446744073709551615) -> None:
        """
        Copy velocity data (Vector3) for the specified vertex range into an externally-owned buffer.
        Args:
            buffer_view: Destination buffer view to copy velocity data into.
            vertex_offset: Starting vertex index (default: 0).
            vertex_count: Number of vertices to include (default: all).
        """
    def create_geometry(self, vertex_offset: typing.SupportsInt | typing.SupportsIndex = 0, vertex_count: typing.SupportsInt | typing.SupportsIndex = 18446744073709551615) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Create geometry from state data.
        Args:
            vertex_offset: Starting vertex index (default: 0).
            vertex_count: Number of vertices to include (default: all).
        Returns:
            Geometry: Geometry created from state data.
        """
    def vertex_count(self) -> int:
        """
        Get the number of vertices.
        Returns:
            int: Number of vertices.
        """
class IEngine:
    """
    Interface for engine implementations.
    """
class Object:
    """
    Object class representing a simulation object containing geometries.
    """
    class Geometries:
        """
        Collection of geometries belonging to an object.
        """
        @typing.overload
        def create(self, simplicial_complex: uipc._native.pyuipc.geometry.SimplicialComplex) -> tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot]:
            """
            Create geometry from a simplicial complex (rest geometry is auto-generated).
            Args:
                simplicial_complex: SimplicialComplex to create geometry from.
            Returns:
                tuple: Pair of (geometry, rest_geometry).
            """
        @typing.overload
        def create(self, simplicial_complex: uipc._native.pyuipc.geometry.SimplicialComplex, rest_simplicial_complex: uipc._native.pyuipc.geometry.SimplicialComplex) -> tuple[uipc._native.pyuipc.geometry.SimplicialComplexSlot, uipc._native.pyuipc.geometry.SimplicialComplexSlot]:
            """
            Create geometry from a simplicial complex with explicit rest geometry.
            Args:
                simplicial_complex: SimplicialComplex to create geometry from.
                rest_simplicial_complex: Rest state simplicial complex.
            Returns:
                tuple: Pair of (geometry, rest_geometry).
            """
        @typing.overload
        def create(self, implicit_geometry: uipc._native.pyuipc.geometry.ImplicitGeometry) -> tuple[uipc._native.pyuipc.geometry.ImplicitGeometrySlot, uipc._native.pyuipc.geometry.ImplicitGeometrySlot]:
            """
            Create geometry from an implicit geometry (rest geometry is auto-generated).
            Args:
                implicit_geometry: ImplicitGeometry to create geometry from.
            Returns:
                tuple: Pair of (geometry, rest_geometry).
            """
        @typing.overload
        def create(self, implicit_geometry: uipc._native.pyuipc.geometry.ImplicitGeometry, rest_implicit_geometry: uipc._native.pyuipc.geometry.ImplicitGeometry) -> tuple[uipc._native.pyuipc.geometry.ImplicitGeometrySlot, uipc._native.pyuipc.geometry.ImplicitGeometrySlot]:
            """
            Create geometry from an implicit geometry with explicit rest geometry.
            Args:
                implicit_geometry: ImplicitGeometry to create geometry from.
                rest_implicit_geometry: Rest state implicit geometry.
            Returns:
                tuple: Pair of (geometry, rest_geometry).
            """
        @typing.overload
        def create(self, geometry: uipc._native.pyuipc.geometry.Geometry) -> tuple[uipc._native.pyuipc.geometry.GeometrySlot, uipc._native.pyuipc.geometry.GeometrySlot]:
            """
            Create geometry from an existing geometry (rest geometry is auto-generated).
            Args:
                geometry: Geometry to create from.
            Returns:
                tuple: Pair of (geometry, rest_geometry).
            """
        @typing.overload
        def create(self, geometry: uipc._native.pyuipc.geometry.Geometry, rest_geometry: uipc._native.pyuipc.geometry.Geometry) -> tuple[uipc._native.pyuipc.geometry.GeometrySlot, uipc._native.pyuipc.geometry.GeometrySlot]:
            """
            Create geometry from an existing geometry with explicit rest geometry.
            Args:
                geometry: Geometry to create from.
                rest_geometry: Rest state geometry.
            Returns:
                tuple: Pair of (geometry, rest_geometry).
            """
        def ids(self) -> numpy.typing.NDArray[numpy.int32]:
            """
            Get the IDs of all geometries in the collection.
            Returns:
                numpy.ndarray: Array of geometry IDs.
            """
    def __repr__(self) -> str:
        """
        String representation of the object.
        Returns:
            str: String representation.
        """
    def geometries(self) -> Object.Geometries:
        """
        Get the geometries collection.
        Returns:
            Geometries: Collection of geometries.
        """
    def id(self) -> int:
        """
        Get the object ID.
        Returns:
            int: Object ID.
        """
    def name(self) -> str:
        """
        Get the object name.
        Returns:
            str: Object name.
        """
class PyIEngine(IEngine):
    """
    Python-implementable engine interface.
    """
    def __init__(self) -> None:
        """
        Create a new PyIEngine instance.
        """
    def do_advance(self) -> None:
        """
        Advance the simulation by one step.
        """
    def do_dump(self) -> bool:
        """
        Dump engine state.
        """
    def do_init(self) -> None:
        """
        Initialize the engine.
        """
    def do_recover(self, dst_frame: typing.SupportsInt | typing.SupportsIndex) -> bool:
        """
        Recover engine state to a specific frame.
        Args:
            dst_frame: Target frame number.
        """
    def do_retrieve(self) -> None:
        """
        Retrieve engine state.
        """
    def do_sync(self) -> None:
        """
        Synchronize engine state.
        """
    def do_to_json(self) -> json:
        """
        Convert engine state to JSON.
        Returns:
            dict: JSON representation of engine state.
        """
    def features(self) -> FeatureCollection:
        """
        Get engine features.
        Returns:
            FeatureCollection: Reference to feature collection.
        """
    def get_frame(self) -> int:
        """
        Get the current frame number.
        Returns:
            int: Current frame number.
        """
    def status(self) -> EngineStatusCollection:
        """
        Get engine status collection.
        Returns:
            EngineStatusCollection: Reference to status collection.
        """
    def world(self) -> World:
        """
        Get the world.
        Returns:
            Reference to the world object.
        """
class SanityCheckMessage:
    """
    SanityCheckMessage class representing a sanity check result message.
    """
    def geometries(self) -> dict[str, uipc._native.pyuipc.geometry.Geometry]:
        """
        Get the list of geometry IDs associated with this message.
        Returns:
            list: List of geometry IDs.
        """
    def id(self) -> int:
        """
        Get the message ID.
        Returns:
            int: Message ID.
        """
    def is_empty(self) -> bool:
        """
        Check if the message is empty.
        Returns:
            bool: True if empty, False otherwise.
        """
    def message(self) -> str:
        """
        Get the message text.
        Returns:
            str: Message text.
        """
    def name(self) -> str:
        """
        Get the message name.
        Returns:
            str: Message name.
        """
    def result(self) -> SanityCheckResult:
        """
        Get the check result.
        Returns:
            SanityCheckResult: Result of the check.
        """
class SanityCheckResult:
    """
    Sanity check result enumeration.
    
    Members:
    
      Success
    
      Warning
    
      Error
    """
    Error: typing.ClassVar[SanityCheckResult]  # value = <SanityCheckResult.Error: 2>
    Success: typing.ClassVar[SanityCheckResult]  # value = <SanityCheckResult.Success: 0>
    Warning: typing.ClassVar[SanityCheckResult]  # value = <SanityCheckResult.Warning: 1>
    __members__: typing.ClassVar[dict[str, SanityCheckResult]]  # value = {'Success': <SanityCheckResult.Success: 0>, 'Warning': <SanityCheckResult.Warning: 1>, 'Error': <SanityCheckResult.Error: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SanityChecker:
    """
    SanityChecker class for validating scene and geometry data.
    """
    def check(self) -> SanityCheckResult:
        """
        Run all sanity checks.
        Returns:
            SanityCheckResult: The result of the sanity check.
        """
    def clear(self) -> None:
        """
        Clear all sanity check messages.
        """
    def errors(self) -> dict[int, SanityCheckMessage]:
        """
        Get all error messages.
        Returns:
            list: List of error SanityCheckMessage objects.
        """
    def infos(self) -> dict[int, SanityCheckMessage]:
        """
        Get all info messages.
        Returns:
            list: List of info SanityCheckMessage objects.
        """
    def report(self) -> None:
        """
        Get a report of all sanity check messages.
        Returns:
            list: List of SanityCheckMessage objects.
        """
    def warns(self) -> dict[int, SanityCheckMessage]:
        """
        Get all warning messages.
        Returns:
            list: List of warning SanityCheckMessage objects.
        """
class Scene:
    """
    Scene class representing a simulation scene containing objects, geometries, and constitutions.
    """
    class ConfigAttributes:
        """
        Configuration attributes for the scene.
        """
        def __repr__(self) -> str:
            """
            String representation of the attributes.
            Returns:
                str: Formatted JSON string.
            """
        def create(self, name: str, object: typing.Any) -> uipc._native.pyuipc.geometry.IAttributeSlot:
            """
            Create a new attribute from a Python object.
            Args:
                name: Name for the new attribute.
                object: Python object to create attribute from (can be scalar, array, or numpy array).
            Returns:
                AttributeSlot: The created attribute slot.
            """
        def destroy(self, name: str) -> None:
            """
            Destroy an attribute by name.
            Args:
                name: Name of the attribute to destroy.
            """
        def find(self, name: str) -> uipc._native.pyuipc.geometry.IAttributeSlot:
            """
            Find an attribute by name.
            Args:
                name: Name of the attribute to find.
            Returns:
                AttributeSlot or None: The attribute slot if found, None otherwise.
            """
        def share(self, name: str, attribute: uipc._native.pyuipc.geometry.IAttributeSlot) -> None:
            """
            Share an existing attribute slot with a new name.
            Args:
                name: New name for the shared attribute.
                attribute: Attribute slot to share.
            """
        def to_json(self) -> json:
            """
            Convert attributes to JSON representation.
            Returns:
                dict: JSON dictionary representation of the attributes.
            """
    class Geometries:
        """
        Collection of geometries in the scene.
        """
        def find(self, id: typing.SupportsInt | typing.SupportsIndex) -> tuple[uipc._native.pyuipc.geometry.GeometrySlot, uipc._native.pyuipc.geometry.GeometrySlot]:
            """
            Find geometry and rest geometry by ID.
            Args:
                id: Geometry ID.
            Returns:
                tuple: Pair of (geometry, rest_geometry).
            """
    class Objects:
        """
        Collection of objects in the scene.
        """
        def create(self, name: str) -> Object:
            """
            Create a new object with the given name.
            Args:
                name: Name of the object to create.
            Returns:
                Object: The created object.
            """
        def destroy(self, id: typing.SupportsInt | typing.SupportsIndex) -> None:
            """
            Destroy an object by ID.
            Args:
                id: Object ID to destroy.
            """
        @typing.overload
        def find(self, id: typing.SupportsInt | typing.SupportsIndex) -> Object:
            """
            Find an object by ID.
            Args:
                id: Object ID.
            Returns:
                Object or None: The object if found, None otherwise.
            """
        @typing.overload
        def find(self, name: str) -> list:
            """
            Find all objects with the given name.
            Args:
                name: Object name.
            Returns:
                list: List of objects with the given name.
            """
        def size(self) -> int:
            """
            Get the number of objects in the collection.
            Returns:
                int: Number of objects.
            """
    @staticmethod
    def default_config() -> json:
        """
        Get the default scene configuration.
        Returns:
            dict: Default configuration dictionary.
        """
    def __init__(self, config: json = {'cfl': {'enable': 0}, 'collision_detection': {'method': 'info_stackless_bvh'}, 'contact': {'adaptive': {'init_kappa': 1000000000.0, 'max_kappa': 100000000000.0, 'min_kappa': 100000000.0}, 'al-ipc': {'alpha_lower_bound': 1e-06, 'decay_factor': 0.3, 'mu_scale_abd': 100000.0, 'mu_scale_fem': 50000000.0, 'toi_threshold': 0.1}, 'constitution': 'ipc', 'd_hat': 0.01, 'enable': 1, 'eps_velocity': 0.01, 'friction': {'enable': 1}}, 'diff_sim': {'enable': 0}, 'dt': 0.01, 'extras': {'debug': {'dump_linear_pcg': 0, 'dump_linear_system': 0, 'dump_mas_matrices': 0, 'dump_surface': 0}, 'strict_mode': {'enable': 0}}, 'gravity': [[0.0], [-9.8], [0.0]], 'integrator': {'type': 'bdf1'}, 'line_search': {'max_iter': 8, 'report_energy': 0}, 'linear_system': {'abd_full_block_preconditioner': 0, 'check_interval': 5, 'fused_pcg': {'fused_preconditioner_enable': 1, 'graph_enable': 0}, 'solver': 'fused_pcg', 'tol_rate': 0.001}, 'newton': {'ccd_tol': 1.0, 'max_iter': 1024, 'min_iter': 1, 'semi_implicit': {'beta_tol': 0.001, 'enable': 0}, 'transrate_tol': 0.1, 'use_adaptive_tol': 0, 'velocity_tol': 0.05}, 'sanity_check': {'enable': 1, 'mode': 'normal'}}) -> None:
        """
        Create a new scene.
        Args:
            config: Configuration dictionary (optional, uses default if not provided).
        """
    def __repr__(self) -> str:
        """
        String representation of the scene.
        Returns:
            str: String representation.
        """
    def animator(self) -> Animator:
        """
        Get the animator for the scene.
        Returns:
            Animator: Reference to the scene animator.
        """
    def config(self) -> Scene.ConfigAttributes:
        """
        Get the scene configuration.
        Returns:
            dict: Configuration dictionary.
        """
    def constitution_tabular(self) -> ConstitutionTabular:
        """
        Get the constitution tabular (constitution configuration).
        Returns:
            ConstitutionTabular: Reference to the constitution tabular.
        """
    def contact_tabular(self) -> ContactTabular:
        """
        Get the contact tabular (contact system configuration).
        Returns:
            ContactTabular: Reference to the contact tabular.
        """
    def diff_sim(self) -> DiffSim:
        """
        Get the differential simulator for the scene.
        Returns:
            DiffSim: Reference to the differential simulator.
        """
    def geometries(self) -> Scene.Geometries:
        """
        Get the geometries collection.
        Returns:
            Geometries: Collection of geometries in the scene.
        """
    def objects(self) -> Scene.Objects:
        """
        Get the objects collection.
        Returns:
            Objects: Collection of objects in the scene.
        """
    def subscene_tabular(self) -> SubsceneTabular:
        """
        Get the subscene tabular (subscene configuration).
        Returns:
            SubsceneTabular: Reference to the subscene tabular.
        """
class SceneFactory:
    """
    SceneFactory class for creating scenes from various sources.
    """
    def __init__(self) -> None:
        """
        Create a new SceneFactory instance.
        """
    def commit_from_json(self, json: json) -> SceneSnapshotCommit:
        """
        Apply commit changes from JSON.
        Args:
            json: JSON dictionary containing commit changes.
        """
    def commit_to_json(self, reference: SceneSnapshotCommit) -> json:
        """
        Generate commit JSON from a reference snapshot.
        Args:
            reference: Reference SceneSnapshot.
        Returns:
            dict: JSON dictionary containing commit changes.
        """
    def from_json(self, json: json) -> SceneSnapshot:
        """
        Create a scene from JSON.
        Args:
            json: JSON dictionary representing the scene.
        Returns:
            Scene: Created scene.
        """
    def from_snapshot(self, snapshot: SceneSnapshot) -> Scene:
        """
        Create a scene from a scene snapshot.
        Args:
            snapshot: SceneSnapshot to create scene from.
        Returns:
            Scene: Created scene.
        """
    def to_json(self, arg0: SceneSnapshot) -> json:
        """
        Convert factory state to JSON.
        Returns:
            dict: JSON representation of the factory state.
        """
class SceneIO:
    """
    SceneIO class for loading and saving scenes to/from files and JSON.
    """
    @staticmethod
    def from_json(json: json) -> Scene:
        """
        Create a scene from JSON.
        Args:
            json: JSON dictionary representing the scene.
        Returns:
            Scene: Scene created from JSON.
        """
    @staticmethod
    def load(filename: str) -> Scene:
        """
        Load a scene from a file.
        Args:
            filename: Input file path.
        Returns:
            Scene: Loaded scene.
        """
    def __init__(self, scene: Scene) -> None:
        """
        Create a SceneIO instance for a scene.
        Args:
            scene: Scene to perform I/O operations on.
        """
    def commit(self, last: SceneSnapshot, name: str) -> None:
        """
        Commit scene changes to a file.
        Args:
            last: Last scene snapshot for comparison.
            name: Output file path.
        Returns:
            SceneSnapshot: New scene snapshot after commit.
        """
    def commit_to_json(self, reference: SceneSnapshot) -> json:
        """
        Commit scene changes to JSON.
        Args:
            reference: Reference scene snapshot for comparison.
        Returns:
            dict: JSON dictionary containing committed changes.
        """
    def save(self, filename: str) -> None:
        """
        Save the scene to a file.
        Args:
            filename: Output file path.
        """
    def simplicial_surface(self, dim: typing.SupportsInt | typing.SupportsIndex = -1) -> uipc._native.pyuipc.geometry.SimplicialComplex:
        """
        Get simplicial surface geometry.
        Args:
            dim: Dimension of simplices to extract (-1 for all dimensions).
        Returns:
            SimplicialComplex: Simplicial surface geometry.
        """
    def to_json(self) -> json:
        """
        Convert scene to JSON representation.
        Returns:
            dict: JSON representation of the scene.
        """
    def update(self, filename: str) -> None:
        """
        Update scene from a file.
        Args:
            filename: Input file path.
        Returns:
            SceneSnapshot: Scene snapshot after update.
        """
    def update_from_json(self, commit_json: json) -> None:
        """
        Update scene from JSON.
        Args:
            commit_json: JSON dictionary containing scene updates.
        Returns:
            SceneSnapshot: Scene snapshot after update.
        """
    def write_surface(self, filename: str) -> None:
        """
        Write surface geometry to a file.
        Args:
            filename: Output file path.
        """
class SceneSnapshot:
    """
    SceneSnapshot class representing a snapshot of scene state.
    """
    def __init__(self, scene: Scene) -> None:
        """
        Create a snapshot from a scene.
        Args:
            scene: Scene to snapshot.
        """
    def __sub__(self, other: SceneSnapshot) -> SceneSnapshotCommit:
        """
        Compute the difference between two snapshots (commit).
        Args:
            other: Other snapshot to compare with.
        Returns:
            SceneSnapshotCommit: Commit representing the difference.
        """
class SceneSnapshotCommit:
    """
    SceneSnapshotCommit class representing changes between two scene snapshots.
    """
    def __init__(self, dst: SceneSnapshot, src: SceneSnapshot) -> None:
        """
        Create a commit from two snapshots.
        Args:
            dst: Destination snapshot.
            src: Source snapshot.
        """
class SubsceneElement:
    """
    SubsceneElement class representing a subscene element (object or geometry).
    """
    def __init__(self, id: typing.SupportsInt | typing.SupportsIndex, name: str) -> None:
        """
        Create a subscene element.
        Args:
            id: Element ID.
            name: Element name.
        """
    def apply_to(self, object: uipc._native.pyuipc.geometry.Geometry) -> uipc._native.pyuipc.geometry.AttributeSlotI32:
        """
        Apply this subscene element to an object.
        Args:
            object: Object to apply to.
        """
    def id(self) -> int:
        """
        Get the element ID.
        Returns:
            int: Element ID.
        """
    def name(self) -> str:
        """
        Get the element name.
        Returns:
            str: Element name.
        """
class SubsceneModel:
    """
    SubsceneModel class representing subscene parameters between two elements.
    """
    def config(self) -> json:
        """
        Get the configuration dictionary.
        Returns:
            dict: Configuration dictionary.
        """
    def is_enabled(self) -> bool:
        """
        Check if the subscene model is enabled.
        Returns:
            bool: True if enabled, False otherwise.
        """
    def topo(self) -> numpy.typing.NDArray[numpy.int32]:
        """
        Get the topology IDs.
        Returns:
            numpy.ndarray: Array of two integers representing the topology IDs.
        """
class SubsceneModelCollection:
    """
    Collection of subscene models with attributes.
    """
    def __repr__(self) -> str:
        """
        String representation of the collection.
        Returns:
            str: Formatted JSON string.
        """
    def create(self, name: str, default_value: typing.Any) -> uipc._native.pyuipc.geometry.IAttributeSlot:
        """
        Create a subscene model attribute.
        Args:
            name: Attribute name.
            default_value: Default value for the attribute.
        Returns:
            AttributeSlot: Created attribute slot.
        """
    def find(self, name: str) -> uipc._native.pyuipc.geometry.IAttributeSlot:
        """
        Find a subscene model attribute by name.
        Args:
            name: Attribute name.
        Returns:
            AttributeSlot or None: Attribute slot if found, None otherwise.
        """
class SubsceneTabular:
    """
    SubsceneTabular class managing subscene elements and subscene models between them.
    """
    def at(self, i: typing.SupportsInt | typing.SupportsIndex, j: typing.SupportsInt | typing.SupportsIndex) -> SubsceneModel:
        """
        Get the subscene model between two elements.
        Args:
            i: First element ID.
            j: Second element ID.
        Returns:
            SubsceneModel: Subscene model between the two elements.
        """
    def create(self, name: str = '') -> SubsceneElement:
        """
        Create a new subscene element.
        Args:
            name: Element name (optional).
        Returns:
            SubsceneElement: Created subscene element.
        """
    def default_element(self) -> SubsceneElement:
        """
        Get the default subscene element.
        Returns:
            SubsceneElement: Reference to default element.
        """
    def element_count(self) -> int:
        """
        Get the number of subscene elements.
        Returns:
            int: Number of elements.
        """
    def insert(self, L: SubsceneElement, R: SubsceneElement, enable: bool = False, config: json = {}) -> int:
        """
        Insert a subscene model between two elements.
        Args:
            L: Left element ID.
            R: Right element ID.
            enable: Whether the subscene is enabled (default: False).
            config: Additional configuration dictionary (default: empty).
        """
    def subscene_models(self) -> SubsceneModelCollection:
        """
        Get the subscene model collection.
        Returns:
            SubsceneModelCollection: Collection of subscene models.
        """
class World:
    """
    World class representing the simulation world that manages scenes and simulation state.
    """
    def __init__(self, engine: Engine) -> None:
        """
        Create a world with an engine.
        Args:
            engine: Engine instance to use.
        """
    def advance(self) -> None:
        """
        Advance the simulation by one step.
        """
    def dump(self) -> bool:
        """
        Dump the world state.
        """
    def features(self) -> FeatureCollection:
        """
        Get the feature collection.
        Returns:
            FeatureCollection: Reference to feature collection.
        """
    def frame(self) -> int:
        """
        Get the current frame number.
        Returns:
            int: Current frame number.
        """
    def init(self, scene: Scene) -> None:
        """
        Initialize the world with a scene.
        Args:
            scene: Scene to initialize the world with.
        """
    def is_valid(self) -> bool:
        """
        Check if the world is in a valid state.
        Returns:
            bool: True if valid, False otherwise.
        """
    def recover(self, dst_frame: typing.SupportsInt | typing.SupportsIndex = 18446744073709551615) -> bool:
        """
        Recover the world state to a specific frame.
        Args:
            dst_frame: Target frame number (default: maximum frame).
        """
    def retrieve(self) -> None:
        """
        Retrieve the world state.
        """
    def sanity_checker(self) -> SanityChecker:
        """
        Get the sanity checker.
        Returns:
            SanityChecker: Reference to sanity checker.
        """
    def sync(self) -> None:
        """
        Synchronize the world state.
        """
Error: SanityCheckResult  # value = <SanityCheckResult.Error: 2>
Success: SanityCheckResult  # value = <SanityCheckResult.Success: 0>
Warning: SanityCheckResult  # value = <SanityCheckResult.Warning: 1>
